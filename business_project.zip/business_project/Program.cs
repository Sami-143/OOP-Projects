﻿using business_project.BL;
using business_project.DL;
using business_project.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace business_project
{
    class Program
    {
        static void Main(string[] args)
        {

            DataTypeDL.SetUsersPath(UserDL.GetPathforUsersFile());
            DataTypeDL.SetProductsPath(ProductDL.GetPathForProductsFile());

            DataTypeDL.SetCheck(UserDL.ReadData(DataTypeDL.GetUsersPath()));
            DataTypeDL.SetCheck1(ProductDL.ReadData1(DataTypeDL.GetProductsPath()));

            UserUI.DataRead(DataTypeDL.GetCheck());
            ProductUI.DataRead1(DataTypeDL.GetCheck1());
            MenuUI.KeyInput();
            DataTypeDL.SetTotal(0);

            do
            {
                DataTypeDL.SetOption(MenuUI.LoginMenu());

                if (DataTypeDL.GetOption() == "1")
                {
                    DataTypeDL.SetSignUpObject(UserUI.TakeInputForSignUp());
                    if (DataTypeDL.GetSignUpObject() != null)
                    {

                        UserBL signedupUser = DataTypeDL.GetSignUpObject();
                        UserDL.AddUsersToList(signedupUser);
                        if(signedupUser.GetRole() == "customer")
                        {
                            CustomerDL.AddCustomersToList(new CustomerBL(signedupUser.GetName(), signedupUser.GetPassword(), signedupUser.GetRole()));
                        }
                        UserDL.AddUsersToFile(DataTypeDL.GetUsersPath(), DataTypeDL.GetSignUpObject());
                    }
                }

                else if (DataTypeDL.GetOption() == "2")
                {
                    DataTypeDL.SetSignInObject(UserUI.TakeInputForSignIn());
                    if (DataTypeDL.GetSignInObject() != null)
                    {
                        DataTypeDL.SetSignInObject(UserDL.SignIn(DataTypeDL.GetSignInObject()));
                        if (DataTypeDL.GetSignInObject() == null)
                        {
                            MenuUI.InvalidInput();
                        }

                        else if (DataTypeDL.GetSignInObject().isAdmin())
                        {
                            MenuUI.ValidInput();
                            MenuUI.KeyInput();
                            DataTypeDL.SetFlag(true);
                            while (DataTypeDL.GetFlag())
                            {
                                DataTypeDL.SetAdminOption(MenuUI.AdminMenu());
                                if (DataTypeDL.GetAdminOption() == "1")
                                {
                                    Products add = ProductUI.AddProducts();
                                    ProductDL.AddProductsToList(add);
                                    ProductUI.AddProductsToFile(DataTypeDL.GetProductsPath(), add);
                                }

                                else if (DataTypeDL.GetAdminOption() == "2")
                                {
                                    ProductDL.AddSalesOnProducts();
                                    ProductUI.AddProductsToFile();
                                }

                                else if (DataTypeDL.GetAdminOption() == "3")
                                {
                                    ProductDL.UpdatePricesOfProducts();
                                    ProductUI.AddProductsToFile();
                                }

                                else if (DataTypeDL.GetAdminOption() == "4")
                                {
                                    ProductDL.RemoveProducts();
                                    //ProductDL.removeFromList();
                                    ProductUI.AddProductsToFile();
                                }

                                else if (DataTypeDL.GetAdminOption() == "5")
                                {
                                    ProductUI.SearchProduct();
                                }

                                else if (DataTypeDL.GetAdminOption() == "6")
                                {
                                    UserDL.ChangeAdminLoginCredentials();
                                    UserDL.AddUsersToFile();
                                }

                                else if (DataTypeDL.GetAdminOption() == "7")
                                {
                                    ProductUI.ViewFeedbacks();
                                }

                                else if (DataTypeDL.GetAdminOption() == "8")
                                {
                                    ProductUI.ViewAllProducts();
                                }

                                else if (DataTypeDL.GetAdminOption() == "9")
                                {
                                    DataTypeDL.SetTotal(ProductDL.FulfillOrders());
                                }

                                else if (DataTypeDL.GetAdminOption() == "10")
                                {
                                    DataTypeDL.SetFlag(false);

                                }

                            }
                        }

                        else if (DataTypeDL.GetSignInObject().isCustomer())
                        {
                            MenuUI.ValidInput();
                            MenuUI.KeyInput();
                            DataTypeDL.SetFlag1(true);
                            while (DataTypeDL.GetFlag1())
                            {
                                DataTypeDL.SetCustomerOption(MenuUI.CustomerMenu());

                                if (DataTypeDL.GetCustomerOption() == "1")
                                {
                                    ProductUI.ViewAllProducts();
                                }

                                else if (DataTypeDL.GetCustomerOption() == "2")
                                {
                                    ProductUI.SearchProduct();
                                }

                                else if (DataTypeDL.GetCustomerOption() == "3")
                                {
                                    ProductDL.OrderProduct(DataTypeDL.GetSignInObject());
                                }

                                else if (DataTypeDL.GetCustomerOption() == "4")
                                {
                                    ProductUI.ViewCart();
                                }

                                else if (DataTypeDL.GetCustomerOption() == "5")
                                {
                                    UserDL.ChangeCustomerLoginCredentials();
                                    UserDL.AddUsersToFile();
                                }

                                else if (DataTypeDL.GetCustomerOption() == "6")
                                {
                                    ProductUI.AddBillingInfo();
                                }

                                else if (DataTypeDL.GetCustomerOption() == "7")
                                {
                                    ProductUI.GenerateInvoice(DataTypeDL.GetTotal());
                                }

                                else if (DataTypeDL.GetCustomerOption() == "8")
                                {
                                    ProductUI.GiveFeedBacks();
                                }

                                else if (DataTypeDL.GetCustomerOption() == "9")
                                {
                                    //ProductUI.ViewOrderHistory(DataTypeDL.GetTotal());
                                    double highest= ProductDL.ProductWithHighestPrice();
                                    ProductDL.SortProducts(highest);
                                    MenuUI.KeyInput();
                                }

                                else if (DataTypeDL.GetCustomerOption() == "10")
                                {
                                    DataTypeDL.SetFlag1(false);
                                }
                            }

                        }
                    }
                }
                MenuUI.KeyInput();
            } while (DataTypeDL.GetOption() != "3");
        }
    }
}
