﻿using business_project.BL;
using business_project.UI;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace business_project.DL
{
    class ProductDL
    {
        public static List<Products> products = new List<Products>();
        //public static List<ProductBL> orders = new List<ProductBL>();
        public static List<string> feedbacksName = new List<string>();
        public static List<string> feedbacks = new List<string>();

        public static string GetPathForProductsFile()
        {
            string path = @"D:\PROGRAMMING\OOP\programs\OOP PROJECT\business_project\productsFile.txt";
            return path;
        }
        public static void AddProductsToList(Products product)
        {
            products.Add(product);
        }



        public static bool ReadData1(string path1)
        {
            if (File.Exists(path1))
            {
                StreamReader fileVariable = new StreamReader(path1);
                string record;
                while ((record = fileVariable.ReadLine()) != null)
                {
                    string pname = UserDL.parseData(record, 1);
                    string category = UserDL.parseData(record, 2);
                    double price = double.Parse(UserDL.parseData(record, 3));
                    int stock = int.Parse(UserDL.parseData(record, 4));
                    if (category == "shirts")
                    {
                        Shirts s = new Shirts(pname, price, stock);
                        AddProductsToList(s);
                    }

                    else if (category == "pants")
                    {
                        Pants p = new Pants(pname, price, stock);
                        AddProductsToList(p);
                    }

                    if (category == "shoes")
                    {
                        Shoes sh = new Shoes(pname, price, stock);
                        AddProductsToList(sh);
                    }
                }
                fileVariable.Close();
                return true;
            }
            return false;
        }

        public static void AddSalesOnProducts()
        {
            MenuUI.ClearScreen();
            MenuUI.TopHeader();
            while (true)
            {
                Console.Write("ENTER THE CATEGORY OF THE PRODUCT ON WHICH YOU WANT TO ADD DISCOUNT: ");
                string category = Console.ReadLine();
                bool check = Validations.CheckCategory(category);
                if (check == true)
                {
                    Console.Write("ENTER HOW MANY PERCENT DISCOUNT YOU WANT TO ADD: ");
                    int sale = int.Parse(Console.ReadLine());
                    foreach (Products p in products)
                    {
                        if (category == p.GetType())
                        {
                            double discount = p.GetProductPrice() - ((p.GetProductPrice() * sale) / 100);
                            Console.WriteLine("DISCOUNTED PRICE OF " + p.GetProductName() + " IS " + discount);
                            p.SetProductPrice(discount);

                        }
                    }
                    MenuUI.KeyInput();
                    break;
                }
            }
        }
        public static Products UpdatePricesOfProducts()
        {
            MenuUI.ClearScreen();
            MenuUI.TopHeader();
            double newPrice;
            Console.WriteLine("--> CHANGE THE PRICES ");
            Console.WriteLine(".....................");
            Console.WriteLine("");
            Console.Write("ENTER THE NAME OF THE PRODUCT WHOSE PRICE YOU WANT TO CHANGE: ");
            string pname = Console.ReadLine();
            foreach (Products p in products)
            {
                if (pname == p.GetProductName())
                {
                    while (true)
                    {
                        Console.Write("ENTER THE NEW PRICE OF " + p.GetProductName() + ": ");
                        newPrice = double.Parse(Console.ReadLine());
                        bool check = Validations.CheckPrice(newPrice);
                        if (check == true)
                        {
                            p.SetProductPrice(newPrice);
                            Console.WriteLine("THE NEW PRICE OF " + p.GetProductName() + " IS " + p.GetProductPrice());
                            Console.WriteLine("PRICE UPDATED.");
                            MenuUI.KeyInput();
                            return p;
                        }
                    }
                }
            }
            return null;

        }

        //  public static void RemoveProducts()
        //  {
        //      MenuUI.ClearScreen();
        //      MenuUI.TopHeader();
        //      Console.Write("ENTER THE NAME OF THE PRODUCT YOU WANT TO REMOVE: ");
        //      string name = Console.ReadLine();
        //      int index = 0;
        //      foreach (Products p in products)
        //      {
        //          if (name != p.GetProductName())
        //          {
        //              index++;
        //          }
        //      }
        //      products.RemoveAt(index);
        //      Console.WriteLine("YOUR PRODUCT HAS BEEN REMOVED.");
        //      MenuUI.KeyInput();
        //  }

        public static void OrderProduct(UserBL signedInUser)
        {
            MenuUI.ClearScreen();
            MenuUI.TopHeader();
            foreach (CustomerBL c in CustomerDL.customers)
            {
                if (signedInUser.GetName() == c.GetName() && signedInUser.GetPassword() == c.GetPassword())
                {
                    Console.Write("ENTER HOW MANY PRODUCTS YOU WANT TO ENTER: ");
                    int index = int.Parse(Console.ReadLine());
                    for (int i = 0; i < index; i++)
                    {
                        Console.Write("ENTER THE NAME OF THE PRODUCT YOU WANT TO ORDER: ");
                        string productName = Console.ReadLine();

                        foreach (Products p in products)
                        {
                            if (productName == p.GetProductName())
                            {
                                if (p.GetStockQuantity() > 0)
                                {
                                    Console.WriteLine("THE " + productName + " IS AVAILABLE.");
                                    c.orders.Add(p);
                                    p.SetStockQuantity(p.GetStockQuantity() - 1);
                                    Console.WriteLine("THE PRODUCT HAS BEEN ADDED TO CART.");
                                    Console.WriteLine("");
                                }
                            }
                        }

                    }
                }


            }
            MenuUI.KeyInput();
        }
        public static void RemoveProducts()
        {
            MenuUI.ClearScreen();
            MenuUI.TopHeader();
            Console.Write("ENTER THE NAME OF THE PRODUCT YOU WANT TO REMOVE: ");
            string name = Console.ReadLine();
            int i;
            for (i = 0; i < products.Count; i++)
            {
                if (name == products[i].GetProductName())
                {
                    Console.WriteLine("YOUR PRODUCT HAS BEEN REMOVED.");
                    break;
                }
            }
            products.RemoveAt(i);
            MenuUI.KeyInput();
        }
        public static string GetCustomerID()
        {
            Random random = new Random();
            int customerId = random.Next(1000, 10000);
            return customerId.ToString();

        }
        public static double FulfillOrders()
        {
            MenuUI.ClearScreen();
            MenuUI.TopHeader();
            double total = 0;
            foreach (CustomerBL c in CustomerDL.customers)
            {

                for (int idx = 0; idx < c.orders.Count; idx++)
                {
                    if (c.orders != null)
                    {
                        Console.WriteLine(c.orders[idx].GetProductName() + " IS READY.");
                        foreach (Products p in products)
                        {
                            if (c.orders[idx].GetProductName() == p.GetProductName())
                            {
                                total = total + c.orders[idx].GetProductPrice();
                            }

                        }
                        c.orders.Remove(c.orders[idx]);
                    }
                    else
                    {
                        break;
                    }
                }
            }

            Console.WriteLine("ALL ORDERS HAVE BEEN FULFILLED.");
            MenuUI.KeyInput();
            return total;
        }

        public static double ProductWithHighestPrice()
        {
            double highest = -1;
            for (int i = 0; i < products.Count - 1; i++)
            {
                if (highest < products[i].GetProductPrice())
                {
                    highest = products[i].GetProductPrice();
                }
            }
            return highest;
        }

        public static void SortProducts(double highest)
        {
            MenuUI.ClearScreen();
            MenuUI.TopHeader();
            List<Products> sortedList = new List<Products>();
            sortedList = products.OrderByDescending(o => o.GetProductPrice()).ToList();
            foreach (Products p in sortedList)
            {
                Console.WriteLine(p.GetProductName());
                Console.WriteLine(p.GetType());
                Console.WriteLine(p.GetProductPrice());
                Console.WriteLine(p.GetStockQuantity());
                Console.WriteLine("");
            }
        }
    }
}
