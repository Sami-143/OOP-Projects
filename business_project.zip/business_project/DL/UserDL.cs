﻿using business_project.BL;
using business_project.UI;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace business_project.DL
{
    class UserDL
    {
        public static List<UserBL> users = new List<UserBL>();

        public static void AddUsersToList(UserBL user)
        {
            users.Add(user);
        }

        public static string parseData(string record, int field)
        {
            int comma = 1;
            string item = "";
            for (int x = 0; x < record.Length; x++)
            {
                if (record[x] == ',')
                {
                    comma++;
                }
                else if (comma == field)
                {
                    item = item + record[x];
                }
            }
            return item;
        }
        public static bool ReadData(string path)
        {
            if (File.Exists(path))
            {
                StreamReader fileVariable = new StreamReader(path);
                string record;
                while ((record = fileVariable.ReadLine()) != null)
                {
                    string name = parseData(record, 1);
                    string password = parseData(record, 2);
                    string role = parseData(record, 3);
                    UserBL user = new UserBL(name, password, role);
                    if (role == "customer")
                    {
                        CustomerDL.AddCustomersToList(new CustomerBL(name, password, role));
                    }
                    AddUsersToList(user);
                }
                fileVariable.Close();
                return true;
            }
            return false;
        }

        public static void AddUsersToFile(string path, UserBL user)
        {
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(user.GetName() + "," + user.GetPassword() + "," + user.GetRole());
            file.Flush();
            file.Close();
        }

        public static void AddUsersToFile()
        {
            StreamWriter file = new StreamWriter(GetPathforUsersFile());
            foreach (UserBL user in users)
            {
                file.WriteLine(user.GetName() + "," + user.GetPassword() + "," + user.GetRole());
            }
            file.Flush();
            file.Close();
        }

        public static string GetPathforUsersFile()
        {
            string path = @"D:\PROGRAMMING\OOP\programs\OOP PROJECT\business_project\usersFile.txt";
            return path;
        }

        public static UserBL SignIn(UserBL user)
        {
            foreach (UserBL storedUser in users)
            {
                if (user.GetName() == storedUser.GetName() && user.GetPassword() == storedUser.GetPassword())
                {
                    return storedUser;
                }
            }
            return null;
        }

        public static void ChangeAdminLoginCredentials()
        {
            MenuUI.ClearScreen();
            MenuUI.TopHeader();
            bool flag = false;
            string oldUsername;
            string oldPassword;
            string newUsername;
            string newPassword;
            int index = 0;

            Console.WriteLine("--> CHANGE CREDENTIALS ");
            Console.WriteLine(".....................");
            Console.WriteLine("");

            Console.Write("ENTER YOUR OLD USERNAME: ");
            oldUsername = Console.ReadLine();
            Console.Write("ENTER YOUR OLD PASSWORD: ");
            oldPassword = Console.ReadLine();
            Console.WriteLine("");

            for (int idx = 0; idx < users.Count; idx++)
            {
                if ((oldUsername == users[idx].GetName()) && (oldPassword == users[idx].GetPassword()) && (users[idx].isAdmin()))
                {
                    index = idx;
                    flag = true;
                }
            }

            if (flag == true)
            {
                while (true)
                {
                    Console.Write("ENTER YOUR NEW USERNAME: ");
                    newUsername = Console.ReadLine();
                    bool checkName = Validations.CheckUsername(newUsername);
                    if (checkName == true)
                    {
                        while (true)
                        {
                            Console.Write("ENTER YOUR NEW PASSWORD: ");
                            newPassword = Console.ReadLine();
                            bool checkPass = Validations.CheckPassword(newPassword);
                            if (checkPass == true)
                            {
                                users[index].SetName(newUsername);
                                users[index].SetPassword(newPassword);
                                Thread.Sleep(300);
                                Console.Write("CREDENTIALS CHANGED SUCCESSFULLY.");
                            }
                        }
                    }
                }
            }
            else if (flag == false)
            {
                Console.WriteLine("SORRY..YOU HAVE ENTERED WRONG CREDENTIALS.");
            }
            MenuUI.KeyInput();
        }

        public static void ChangeCustomerLoginCredentials()
        {
            MenuUI.ClearScreen();
            MenuUI.TopHeader();
            bool flag = false;
            string oldUsername;
            string oldPassword;
            string newUsername;
            string newPassword;
            int index = 0;

            Console.WriteLine("--> CHANGE CREDENTIALS ");
            Console.WriteLine(".....................");
            Console.WriteLine("");

            Console.Write("ENTER YOUR OLD USERNAME: ");
            oldUsername = Console.ReadLine();
            Console.Write("ENTER YOUR OLD PASSWORD: ");
            oldPassword = Console.ReadLine();
            Console.WriteLine("");

            for (int idx = 0; idx < users.Count; idx++)
            {
                if ((oldUsername == users[idx].GetName()) && (oldPassword == users[idx].GetPassword()) && (users[idx].isCustomer()))
                {
                    index = idx;
                    flag = true;
                }
            }

            if (flag == true)
            {
                Console.Write("ENTER YOUR NEW USERNAME: ");
                newUsername = Console.ReadLine();
                Console.Write("ENTER YOUR NEW PASSWORD: ");
                newPassword = Console.ReadLine();
                users[index].SetName(newUsername);
                users[index].SetPassword(newPassword);
                Thread.Sleep(300);
                Console.Write("CREDENTIALS CHANGED SUCCESSFULLY.");
            }
            else if (flag == false)
            {
                Console.WriteLine("SORRY..YOU HAVE ENTERED WRONG CREDENTIALS.");
            }
            MenuUI.KeyInput();
        }
    }
}

