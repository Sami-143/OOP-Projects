﻿using business_project.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace business_project.DL
{
    class CustomerDL
    {
        public static List<CustomerBL> customers = new List<CustomerBL>();

        public static void AddCustomersToList(CustomerBL customer)
        {
            customers.Add(customer);
        }
    }
}
