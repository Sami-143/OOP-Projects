﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace business_project.BL
{
    class Products
    {
        protected string productName;
        protected double productPrice;
        protected int stockQuantity;

        public Products(string pdtname, double pdtPrice, int stockQuantity)
        {
            this.productName = pdtname;
            this.productPrice = pdtPrice;
            this.stockQuantity = stockQuantity;
        }

        public string GetProductName()
        {
            return productName;
        }

        public void SetProductName(string productName)
        {
            this.productName = productName;
        }

        public double GetProductPrice()
        {
            return productPrice;
        }

        public void SetProductPrice(double productPrice)
        {
            this.productPrice = productPrice;
        }
        public int GetStockQuantity()
        {
            return stockQuantity;
        }

        public void SetStockQuantity(int stockQuantity)
        {
            this.stockQuantity = stockQuantity;
        }

        public new virtual string GetType()
        {
            return null;
        }
    }
}
