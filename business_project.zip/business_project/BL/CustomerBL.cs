﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace business_project.BL
{
    class CustomerBL:UserBL
    {
        private string id;
        private string name;
        private string address;
        private string city;
        private string contact;
        public List<Products> orders = new List<Products>();

        public CustomerBL(string username, string password, string role) : base(username, password, role)
        {
        
        }
        
        public CustomerBL(string id,string name,string address,string city,string contact)
        {
            this.id = id;
            this.name = name;
            this.address = address;
            this.city = city;
            this.contact = contact;
        }

        public override string GetRole()
        {
            return "customer";
        }

        public override void SetId(string id)
        {
            this.id = id;
        }

        public override string GetId()
        {
            return id;
        }

        public override void SetCustomerName(string name)
        {
            this.name = name;
        }
        public override string GetCustomerName()
        {
            return name;
        }

        public override void SetAddress(string address)
        {
            this.address=address;
        }
        public override string GetAddress()
        {
            return address;
        }

        public override void SetCity(string city)
        {
            this.city = city;
        }
        public override string GetCity()
        {
            return city;
        }

        public override void SetContact(string contact)
        {
            this.contact = contact;
        }

        public override string GetContact()
        {
            return contact;
        }
    }
}
