﻿using business_project.DL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace business_project.BL
{
    class Validations
    {
        public static bool check_ROOMNUMBER(string R_no)
        {

            if (R_no.Length <= 3)
            {
                for (int i = 0; i < R_no.Length; i++)
                {
                    if (R_no[i] > 46 && R_no[i] < 56)
                    {
                        continue;
                    }
                    else
                    {
                        Console.WriteLine("\n ROOMNUMBER must be consist of only numeric characters .\n ");
                        return false;
                    }
                }
                return true;
            }
            else
            {
                Console.WriteLine("\n Only three characters..");
                return false;
            }
        }
        public static bool check_SEASON(string swsa)
        {
            if (swsa == "summer" || swsa == "winter" || swsa == "spring" || swsa == "autumn")
            {
                return true;
            }
            else
            {
                Console.WriteLine("INVALID INPUT :) ");
                return false;
            }
        }
        public static bool check_ADRESS(string ip_adress)
        {
            if (ip_adress.Length < 15)
            {
                for (int i = 0; i < ip_adress.Length; i++)
                {
                    if ((ip_adress[i] >= 48 && ip_adress[i] <= 57) || (ip_adress[i] > 64 && ip_adress[i] < 89) || (ip_adress[i] > 96 && ip_adress[i] < 122) || (ip_adress[i] == 35))
                    {
                        continue;
                    }
                    else
                    {
                        Console.WriteLine("\n ADRESS must be consist of only numeric characters ,alphabets and #  .\n ");
                        return false;
                    }
                }
                return true;
            }
            else
            {
                return false;
            }
        }
        public static bool check_PHONENUMBER(string mobile_no)
        {
            if (mobile_no.Length == 11)
            {
                for (int i = 0; i < mobile_no.Length; i++)
                {
                    if (mobile_no[i] >= 48 && mobile_no[i] <= 57)
                    {
                        continue;
                    }
                    else
                    {
                        Console.WriteLine("\n PHONENUMBER must be consist of only numeric characters .\n ");
                        return false;
                    }
                }
                return true;
            }
            else
            {
                Console.WriteLine("\n Only eleven characters..");
                return false;
            }
        }

        public static bool check_customerID(string ID)
        {
            for (int i = 0; i < CustomerDL.customers.Count; i++)
            {
                if (ID == CustomerDL.customers[i].GetId())
                {
                    Console.WriteLine(" customer ID already exists.\n");
                    return false;
                }
            }
            if (ID.Length == 4)
            {
                for (int i = 0; i < ID.Length; i++)
                {
                    if ((ID[i] >= 48 && ID[i] <= 57))
                    {
                        continue;
                    }
                    else
                    {
                        Console.WriteLine("\n Customer ID must be consist of only numeric characters.\n ");
                        return false;
                    }
                }
                return true;
            }
            else
            {
                Console.WriteLine("\n Only four characters..");
                return false;
            }
        }
        public static bool CheckPassword(string pass)
        {
            if (pass.Length == 8)
            {
                for (int i = 0; i < pass.Length; i++)
                {
                    if ((pass[i] >= 48 && pass[i] <= 57) || (pass[i] > 64 && pass[i] < 89) || (pass[i] > 96 && pass[i] < 122))
                    {
                        continue;
                    }
                    else
                    {
                        Console.WriteLine("\n PASSWORD MUST BE CONSIST OF ONLY NUMERIC CHARACTERS AND ALPHABETS.\n ");
                        return false;
                    }
                }
                return true;
            }
            else
            {
                Console.WriteLine("\n ONLY EIGHT CHARACTERS.");
                return false;
            }
        }
        public static bool CheckCredentials(string username, string password)
        {
            if (password.Length < 8)
            {
                return true;
            }

            bool flag = false;

            for (int i = 0; i < password.Length; i++)
            {
                if ((password[i] >= 48 && password[i] <= 57) || (password[i] > 64 && password[i] < 91) || (password[i] > 96 && password[i] < 123))
                {
                    continue;
                }
                else
                {
                    flag = true;
                    break;
                }
            }

            for (int i = 0; i < username.Length; i++)
            {
                if ((username[i]>=48 && username[i]<=57) || (username[i] > 64 && username[i] < 91) || (username[i] > 96 && username[i] < 123))
                {
                    continue;
                }
                else
                {
                    flag = true;
                    break;
                }
            }
            if (flag == true)
            {
                Console.WriteLine("NO SPECIAL CHARACTER ALLOWED EXCEPT ALPHABETS. ");
                return false;
            }
            return true;
        }

    }
}
