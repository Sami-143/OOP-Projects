﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace business_project.BL
{
    class Shirts : Products
    {
        public Shirts(string pdtname, double pdtPrice, int stockQuantity) : base(pdtname, pdtPrice, stockQuantity)
        {

        }

        public override string GetType()
        {
            return "shirts";
        }
    }
}
