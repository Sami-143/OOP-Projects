﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace business_project.BL
{
    class UserBL
    {
        protected string username;
        protected string password;
        protected string role;

        public UserBL()
        {

        }
        public UserBL(string username,string password)
        {
            this.username = username;
            this.password = password;
        }

        public UserBL(string username,string password, string role)
        {
            this.username = username;
            this.password = password;
            this.role = role;
        }

        public string GetName()
        {
            return username;
        }

        public void SetName(string username)
        {
            this.username = username;
        }

        public string GetPassword()
        {
            return password;
        }

        public void SetPassword(string password)
        {
            this.password = password;
        }

        public virtual string GetRole()
        {
            return null;
        }

        public void setRole(string role)
        {
            this.role = role;
        }

        public bool isAdmin()
        {
            if (role == "Admin" || role == "admin")
            {
                return true;
            }
            return false;
        }

        public bool isCustomer()
        {
            if (role == "Customer" || role == "customer")
            {
                return true;
            }
            return false;
        }

        public virtual void SetId(string id)
        {
            
        }

        public virtual string GetId()
        {
            return null;
        }

        public virtual void SetCustomerName(string name)
        {
           
        }
        public virtual string GetCustomerName()
        {
            return null;
        }

        public virtual void SetAddress(string address)
        {
            
        }
        public virtual string GetAddress()
        {
            return null;
        }

        public virtual void SetCity(string city)
        {
            
        }
        public virtual string GetCity()
        {
            return null;
        }

        public virtual void SetContact(string contact)
        {
            
        }

        public virtual string GetContact()
        {
            return null;
        }
    }
}
