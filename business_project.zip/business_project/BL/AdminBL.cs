﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace business_project.BL
{
    class AdminBL : UserBL
    {
        public AdminBL(string username, string password, string role) : base(username, password, role)
        {

        }

        public override string GetRole()
        {
            return "admin";
        }
    }
}
