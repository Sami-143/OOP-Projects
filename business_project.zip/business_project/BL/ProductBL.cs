﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace business_project.BL
{
    //class ProductBL
    //{
    //    private string productName;
    //    private string category;
    //    private double productPrice;
    //    private int stockQuantity;
    //
    //    public ProductBL(string pdtname,string category, double pdtPrice,int stockQuantity)
    //    {
    //        this.productName = pdtname;
    //        this.category = category;
    //        this.productPrice = pdtPrice;
    //        this.stockQuantity = stockQuantity;
    //    }
    //
    //    public string GetProductName()
    //    {
    //        return productName;
    //    }
    //
    //    public void SetProductName(string productName)
    //    {
    //        this.productName=productName;
    //    }
    //
    //    public string GetCategory()
    //    {
    //        return category;
    //    }
    //
    //    public void SetCategory(string category)
    //    {
    //        this.category=category;
    //    }
    //
    //    public double GetProductPrice()
    //    {
    //        return productPrice;
    //    }
    //
    //    public void SetProductPrice(double productPrice)
    //    {
    //        this.productPrice=productPrice;
    //    }
    //    public int GetStockQuantity()
    //    {
    //        return stockQuantity;
    //    }
    //
    //    public void SetStockQuantity(int stockQuantity)
    //    {
    //        this.stockQuantity=stockQuantity;
    //    }
    //}
}   //
