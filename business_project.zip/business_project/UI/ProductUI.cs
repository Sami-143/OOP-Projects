﻿using business_project.BL;
using business_project.DL;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace business_project.UI
{
    class ProductUI
    {
        public static Products AddProducts()
        {
            MenuUI.ClearScreen();
            MenuUI.TopHeader();

            Console.Write("-->ENTER PRODUCT NAME: ");
            string pname = Console.ReadLine();
            while (true)
            {
                Console.Write("-->ENTER THE CATEGORY: ");
                string category = Console.ReadLine();

                bool check = Validations.CheckCategory(category);
                if (check == true)
                {
                    while (true)
                    {
                        Console.Write("-->ENTER THE PRODUCT'S PRICE: ");
                        double price = double.Parse(Console.ReadLine());
                        bool checkPrice = Validations.CheckPrice(price);
                        if (checkPrice == true)
                        {
                            while (true)
                            {
                                Console.Write("-->ENTER THE PRODUCT'S STOCK: ");
                                int stock = int.Parse(Console.ReadLine());
                                bool checkStock = Validations.CheckStock(stock);
                                if (checkStock == true)
                                {
                                    if (pname != null && price > 0 && category != null && stock > 0)
                                    {
                                        if (category == "pants")
                                        {
                                            Pants products = new Pants(pname, price, stock);
                                            Console.WriteLine("YOUR PRODUCT HAS BEEN ADDED.");
                                            MenuUI.KeyInput();
                                            return products;
                                        }
                                        if (category == "shirts")
                                        {
                                            Shirts products = new Shirts(pname, price, stock);
                                            Console.WriteLine("YOUR PRODUCT HAS BEEN ADDED.");
                                            MenuUI.KeyInput();
                                            return products;
                                        }
                                        if (category == "shoes")
                                        {
                                            Shoes products = new Shoes(pname, price, stock);
                                            Console.WriteLine("YOUR PRODUCT HAS BEEN ADDED.");
                                            MenuUI.KeyInput();
                                            return products;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        public static void AddProductsToFile(string path, Products product)
        {
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(product.GetProductName() + "," + product.GetType() + "," + product.GetProductPrice() + "," + product.GetStockQuantity());
            file.Flush();
            file.Close();
        }

        public static void AddProductsToFile()
        {
            StreamWriter file = new StreamWriter(ProductDL.GetPathForProductsFile());
            foreach (Products p in ProductDL.products)
            {
                file.WriteLine(p.GetProductName() + "," + p.GetType() + "," + p.GetProductPrice() + "," + p.GetStockQuantity());
            }
            file.Flush();
            file.Close();
        }

        public static void DataRead1(bool check)
        {
            if (check)
            {
                Console.WriteLine("DATA LOADED SUCCESSFULLY.");
            }

            else
            {
                Console.WriteLine("DATA NOT LOADED.");
            }
        }

        public static void SearchProduct()
        {
            MenuUI.ClearScreen();
            MenuUI.TopHeader();
            Console.Write("ENTER THE NAME OF THE PRODUCT: ");
            string productName = Console.ReadLine();
            Console.WriteLine("");
            foreach (Products p in ProductDL.products)
            {
                if (productName == p.GetProductName())
                {
                    Console.WriteLine("--> PRODUCT NAME: " + p.GetProductName());
                    Console.WriteLine("--> PRODUCT CATEGORY: " + p.GetType());
                    Console.WriteLine("--> PRODUCT PRICE: " + p.GetProductPrice());
                    if (p.GetStockQuantity() > 0)
                    {

                        Console.WriteLine("PRODUCT AVAILABLE.");
                    }

                    else if (p.GetStockQuantity() == 0)
                    {
                        Console.WriteLine("THE PRODUCT IS UNAVAILABLE.");
                    }
                }

            }
            MenuUI.KeyInput();
        }

        public static void ViewAllProducts()
        {
            MenuUI.ClearScreen();
            MenuUI.TopHeader();
            Console.WriteLine("");
            Console.WriteLine("--> PRODUCTS ");
            Console.WriteLine("");
            foreach (Products pro in ProductDL.products)
            {
                Console.WriteLine("--> THE NAME OF PRODUCT IS: {0}", pro.GetProductName());
                Console.WriteLine("--> THE CATEGORY OF PRODUCT IS: {0}", pro.GetType());
                Console.WriteLine("--> THE PRICE OF PRODUCT " + pro.GetProductName() + " IS: " + pro.GetProductPrice());
                Console.WriteLine("--> THE AVAILABLE STOCK OF THE PRODUCT IS : " + pro.GetStockQuantity());
                Console.WriteLine("");
            }
            MenuUI.KeyInput();
        }

        public static void ViewCart()
        {
            MenuUI.ClearScreen();
            MenuUI.TopHeader();
            Console.WriteLine("--> YOUR CART");
            Console.WriteLine(".....................");

            Console.Write("ENTER YOUR CUSTOMER ID: ");
            string customerID = Console.ReadLine();
            Console.WriteLine();
            bool userfound = false;
            for (int i = 0; i < CustomerDL.customers.Count; i++)
            {
                if (customerID == CustomerDL.customers[i].GetId())
                {
                    for (int j = 0; j < CustomerDL.customers[i].orders.Count; j++)
                    {
                        Console.WriteLine(CustomerDL.customers[i].orders[j].GetProductName());
                        Console.WriteLine(CustomerDL.customers[i].orders[j].GetType());
                        Console.WriteLine(CustomerDL.customers[i].orders[j].GetProductPrice());
                        Console.WriteLine("");
                    }
                    userfound = true;
                    break;
                }
                if (userfound)
                {
                    break;
                }
            }
            MenuUI.KeyInput();
        }

        public static void AddBillingInfo()
        {
            MenuUI.ClearScreen();
            MenuUI.TopHeader();
            Console.WriteLine("--> BILLING INFO");
            Console.WriteLine(".....................");
            Console.Write("ENTER YOUR USERNAME: ");
            string username = Console.ReadLine();
            Console.Write("ENTER YOUR PASSWORD: ");
            string password = Console.ReadLine();
            foreach (CustomerBL user in CustomerDL.customers)
            {
                if (username == user.GetName() && password == user.GetPassword())
                {
                    Console.Write("YOUR CUSTOMER ID IS: ");
                    string iD = ProductDL.GetCustomerID();
                    Console.WriteLine(iD);
                    Console.Write("ENTER YOUR NAME: ");
                    string name = Console.ReadLine();
                    Console.Write("ENTER YOUR ADDRESS: ");
                    string address = Console.ReadLine();
                    Console.Write("ENTER YOUR CITY: ");
                    string city = Console.ReadLine();
                    Console.Write("ENTER YOUR CONTACT NUMBER: ");
                    string contact = Console.ReadLine();
                    user.SetId(iD);
                    user.SetAddress(address);
                    user.SetCustomerName(name);
                    user.SetCity(city);
                    user.SetContact(contact);
                    Console.WriteLine("BILLING INFORMATION ADDED SUCCESSFULLY.");
                }
            }
            MenuUI.KeyInput();
        }

        public static void GenerateInvoice(double total)
        {
            MenuUI.ClearScreen();
            MenuUI.TopHeader();
            Console.WriteLine("--> PAY SLIP");
            Console.WriteLine(".....................");
            Console.WriteLine("");
            Console.WriteLine();

            Console.Write("ENTER YOUR CUSTOMER ID: ");
            string customerID = Console.ReadLine();
            for (int i = 0; i < CustomerDL.customers.Count; i++)
            {
                if (customerID == CustomerDL.customers[i].GetId())
                {
                    Console.WriteLine("--> YOUR NAME: " + CustomerDL.customers[i].GetCustomerName());
                    Console.WriteLine("--> YOUR ADDRESS: " + CustomerDL.customers[i].GetAddress());
                    Console.WriteLine("--> YOUR CITY: " + CustomerDL.customers[i].GetCity());
                    Console.WriteLine("--> YOUR CONTACT: " + CustomerDL.customers[i].GetContact());
                    Console.WriteLine("");
                    Console.WriteLine("YOU ORDERED: ");
                    Console.WriteLine("");

                    for (int j = 0; j < CustomerDL.customers[i].orders.Count; j++)
                    {
                        Console.WriteLine(CustomerDL.customers[i].orders[j].GetProductName());
                        Console.WriteLine(CustomerDL.customers[i].orders[j].GetType());
                        Console.WriteLine(CustomerDL.customers[i].orders[j].GetProductPrice());
                        Console.WriteLine("");
                    }

                    Console.WriteLine("--> YOUR TOTAL BILL IS: " + total);
                }
            }


            MenuUI.KeyInput();
        }


        public static void GiveFeedBacks()
        {
            MenuUI.ClearScreen();
            MenuUI.TopHeader();
            Console.WriteLine("--> YOUR FEEDBACKS ");
            Console.WriteLine(".....................");
            Console.WriteLine("");

            Console.Write("ENTER YOUR CUSTOMER ID: ");
            string custID = Console.ReadLine();
            Console.Write("ENTER YOUR FEEDBACK/REVIEW: ");
            string feedback = Console.ReadLine();
            Console.WriteLine("THANK YOU FOR YOUR VALUABLE FEEDBACK..");
            Console.WriteLine("");
            ProductDL.feedbacksName.Add(custID);
            ProductDL.feedbacks.Add(feedback);

            MenuUI.KeyInput();
        }

        public static void ViewFeedbacks()
        {
            MenuUI.ClearScreen();
            MenuUI.TopHeader();
            Console.WriteLine("--> FEEDBACKS BY CUSTOMERS ");
            Console.WriteLine(".....................");
            Console.WriteLine("");

            for (int idx = 0; idx < ProductDL.feedbacks.Count; idx++)
            {
                Console.WriteLine("FEEDBACK BY " + ProductDL.feedbacksName[idx] + ":");
                Console.WriteLine(ProductDL.feedbacks[idx]);
                Console.WriteLine("");
            }
            MenuUI.KeyInput();
        }

        // public static void ViewOrderHistory(double total)
        // {
        //     MenuUI.ClearScreen();
        //     MenuUI.TopHeader();
        //     Console.WriteLine("");
        //     Console.WriteLine("ENTER YOUR CUSTOMER ID");
        //     string customerID = Console.ReadLine();
        //     for (int i = 0; i < CustomerDL.customers.Count; i++)
        //     {
        //         if (customerID == CustomerDL.customers[i].GetId())
        //         {
        //
        //             Console.WriteLine("--> YOUR ORDERS");
        //             Console.WriteLine(".....................");
        //             Console.WriteLine("");
        //
        //             for (int j = 0; j < .orders.Count; j++)
        //             {
        //                 Console.WriteLine(ProductDL.orders[j].GetProductName());
        //                 Console.WriteLine(ProductDL.orders[j].GetProductPrice());
        //                 Console.WriteLine();
        //             }
        //             Console.WriteLine("BILL: " + total);
        //         }
        //     }
        //     MenuUI.KeyInput();
        // }
    }
}
