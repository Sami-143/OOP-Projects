﻿using business_project.BL;
using business_project.DL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace business_project.UI
{
    class UserUI
    {
        public static UserBL TakeInputForSignUp()
        {
            MenuUI.ClearScreen();
            MenuUI.TopHeader();

            Console.WriteLine("--> SIGN UP");
            Console.WriteLine("................");
            while (true)
            {
                Console.Write("ENTER NAME: ");
                string name = Console.ReadLine();
                bool checkName = Validations.CheckUsername(name);
                if (checkName == true)
                {
                    while (true)
                    {
                        Console.Write("ENTER PASSWORD: ");
                        string password = Console.ReadLine();
                        bool checkPass = Validations.CheckPassword(password);
                        if (checkPass == true)
                        {
                            while (true)
                            {
                                Console.Write("ENTER ROLE: ");
                                string role = Console.ReadLine();
                                if (name != null && password != null && role != null)
                                {

                                    if (role == "customer" || role == "Customer")
                                    {
                                        CustomerBL user = new CustomerBL(name, password, role);
                                        Console.WriteLine("SIGNED UP SUCCESSFULLY.");
                                        return user;
                                    }

                                    if (role == "admin" || role == "Admin")
                                    {
                                        AdminBL user = new AdminBL(name, password, role);
                                        Console.WriteLine("SIGNED UP SUCCESSFULLY.");
                                        return user;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        public static UserBL TakeInputForSignIn()
        {
            MenuUI.ClearScreen();
            MenuUI.TopHeader();

            Console.Write("ENTER NAME: ");
            string name = Console.ReadLine();
            bool check = Validations.CheckUsername(name);
            if (check == true)
            {
                Console.Write("ENTER PASSWORD: ");
                string password = Console.ReadLine();
                bool checkPass = Validations.CheckPassword(password);
                if (checkPass == true)
                {
                    if (name != null && password != null)
                    {
                        UserBL user = new UserBL(name, password);
                        return user;
                    }
                    return null;
                }
                return null;
            }
            MenuUI.KeyInput();
            return null;

        }

        //public static void DataRead(bool check)
        //{
        //    if (check)
        //    {
        //        Console.WriteLine("DATA LOADED SUCCESSFULLY.");
        //    }

        //    else
        //    {
        //        Console.WriteLine("DATA NOT LOADED.");
        //    }
        //}

    }
}
