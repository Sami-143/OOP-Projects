﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace business_project.UI
{
    class MenuUI
    {
        public static void TopHeader()
        {
            Console.WriteLine("********************************************************************************************************");
            Console.WriteLine("********************************************************************************************************");
            Console.WriteLine("**                                                                                                    **");
            Console.WriteLine("**          $       $   $ $ $ $   $     $     $       $   $ $ $ $   $ $ $    $ $ $   $ $ $ $          **");
            Console.WriteLine("**          $ $   $ $   $         $ $   $      $     $    $         $    $  $        $                **");
            Console.WriteLine("**          $   $   $   $ $ $ $   $  $  $       $   $     $ $ $ $   $ $ $    $ $ $   $ $ $ $          **");
            Console.WriteLine("**          $       $   $         $   $ $        $ $      $         $  $          $  $                **");
            Console.WriteLine("**          $       $   $ $ $ $   $     $         $       $ $ $ $   $    $   $ $ $   $ $ $ $          **");
            Console.WriteLine("**                                                                                                    **");
            Console.WriteLine("**                            M O N E Y  C A N  B U Y  H A P P I N E S S                              **");
            Console.WriteLine("**                                                                                                    **");
            Console.WriteLine("**                                        (MENS CLOTHING)                                             **");
            Console.WriteLine("**                                                                                                    **");
            Console.WriteLine("********************************************************************************************************");
            Console.WriteLine("********************************************************************************************************");
        }

        public static string  LoginMenu()
        {
            MenuUI.ClearScreen();
            MenuUI.TopHeader();

            Console.WriteLine("1. SIGN UP TO GET YOUR LOGIN CREDENTIALS");
            Console.WriteLine("2. SIGN IN WITH YOUR LOGIN CREDENTIALS");
            Console.WriteLine("3. EXIT THE APPLICATION");
            Console.WriteLine("");
            Console.Write("-->ENTER THE OPTION TO CONTINUE: ");
            string option = Console.ReadLine() ;
            return option;
        }

        public static void KeyInput()
        {
            Console.WriteLine("");
            Console.WriteLine("PRESS ANY KEY TO CONTINUE...");
            Console.ReadKey();
         }
        public static void ClearScreen()
        {
            Console.Clear();
        }

        public static void InvalidInput()
        {
            Console.WriteLine("INVALID INPUT.");
        }

        public static void ValidInput()
        {
            Console.WriteLine("VALID INPUT.");
        }

        public static string  AdminMenu()
        {
            MenuUI.ClearScreen();
            MenuUI.TopHeader();
            Console.WriteLine("ADMIN MENU");
            Console.WriteLine(".....................");
            Console.WriteLine(" 1. ADD THE PRODUCTS.");
            Console.WriteLine(" 2. ADD THE SALES ON PRODUCTS.");
            Console.WriteLine(" 3. UPDATE THE PRICES OF THE PRODUCTS.");
            Console.WriteLine(" 4. REMOVE THE PRODUCTS.");
            Console.WriteLine(" 5. SEARCH PRODUCT.");
            Console.WriteLine(" 6. CHANGE LOGIN CREDENTIALS.");
            Console.WriteLine(" 7. CHECK REVIEWS.");
            Console.WriteLine(" 8. VIEW ALL PRODUCTS.");
            Console.WriteLine(" 9. FULLFIL ORDERS.");
            Console.WriteLine(" 10. EXIT.");
            Console.Write("-->ENTER THE OPTION TO CONTINUE: ");
            string option = Console.ReadLine();
            return option;
        }

        public static string  CustomerMenu()
        {
            MenuUI.ClearScreen();
            MenuUI.TopHeader();
            Console.WriteLine("CUSTOMER MENU");
            Console.WriteLine(".....................");
            Console.WriteLine(" 1. VIEW ALL PRODUCTS.");
            Console.WriteLine(" 2. SEARCH PRODUCT.");
            Console.WriteLine(" 3. ORDER PRODUCTS.");
            Console.WriteLine(" 4. VIEW CART.");
            Console.WriteLine(" 5. CHANGE LOGIN CREDENTIALS.");
            Console.WriteLine(" 6. ADD BILLING INFORMATION.");
            Console.WriteLine(" 7. GENERATE INVOICE.");
            Console.WriteLine(" 8. GIVE FEEDBACKS.");
            Console.WriteLine(" 9. FILTER PRODUCTS ACCORDING TO PRICES.");
            Console.WriteLine(" 10. EXIT.");
            Console.Write("-->ENTER THE OPTION TO CONTINUE: ");
            string option = Console.ReadLine();
            return option;
        }

        
    }
}
