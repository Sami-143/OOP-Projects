﻿
namespace LOGIN__GMS
{
    partial class frmAdminMainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tblAdminFirstPannel = new System.Windows.Forms.TableLayoutPanel();
            this.tblAdminLeftPannel = new System.Windows.Forms.TableLayoutPanel();
            this.lblChangePassword = new System.Windows.Forms.Label();
            this.lblSearchProduct = new System.Windows.Forms.Label();
            this.lblMostSold = new System.Windows.Forms.Label();
            this.lblSortProduct = new System.Windows.Forms.Label();
            this.lblAddDiscount = new System.Windows.Forms.Label();
            this.lblViewProduct = new System.Windows.Forms.Label();
            this.lblUpdateProduct = new System.Windows.Forms.Label();
            this.lblDeleteProduct = new System.Windows.Forms.Label();
            this.lblAddProduct = new System.Windows.Forms.Label();
            this.lblExit = new System.Windows.Forms.Label();
            this.lblReviews = new System.Windows.Forms.Label();
            this.pbAdminLogo = new System.Windows.Forms.PictureBox();
            this.tblAdmin = new System.Windows.Forms.TableLayoutPanel();
            this.tblAdminFirstPannel.SuspendLayout();
            this.tblAdminLeftPannel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbAdminLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // tblAdminFirstPannel
            // 
            this.tblAdminFirstPannel.ColumnCount = 2;
            this.tblAdminFirstPannel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.10526F));
            this.tblAdminFirstPannel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 82.89474F));
            this.tblAdminFirstPannel.Controls.Add(this.tblAdminLeftPannel, 0, 0);
            this.tblAdminFirstPannel.Controls.Add(this.tblAdmin, 1, 0);
            this.tblAdminFirstPannel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblAdminFirstPannel.Location = new System.Drawing.Point(0, 0);
            this.tblAdminFirstPannel.Name = "tblAdminFirstPannel";
            this.tblAdminFirstPannel.RowCount = 1;
            this.tblAdminFirstPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblAdminFirstPannel.Size = new System.Drawing.Size(1517, 749);
            this.tblAdminFirstPannel.TabIndex = 0;
            // 
            // tblAdminLeftPannel
            // 
            this.tblAdminLeftPannel.ColumnCount = 1;
            this.tblAdminLeftPannel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblAdminLeftPannel.Controls.Add(this.lblChangePassword, 0, 10);
            this.tblAdminLeftPannel.Controls.Add(this.lblSearchProduct, 0, 8);
            this.tblAdminLeftPannel.Controls.Add(this.lblMostSold, 0, 7);
            this.tblAdminLeftPannel.Controls.Add(this.lblSortProduct, 0, 6);
            this.tblAdminLeftPannel.Controls.Add(this.lblAddDiscount, 0, 5);
            this.tblAdminLeftPannel.Controls.Add(this.lblViewProduct, 0, 4);
            this.tblAdminLeftPannel.Controls.Add(this.lblUpdateProduct, 0, 3);
            this.tblAdminLeftPannel.Controls.Add(this.lblDeleteProduct, 0, 2);
            this.tblAdminLeftPannel.Controls.Add(this.lblAddProduct, 0, 1);
            this.tblAdminLeftPannel.Controls.Add(this.lblExit, 0, 11);
            this.tblAdminLeftPannel.Controls.Add(this.lblReviews, 0, 9);
            this.tblAdminLeftPannel.Controls.Add(this.pbAdminLogo, 0, 0);
            this.tblAdminLeftPannel.Dock = System.Windows.Forms.DockStyle.Left;
            this.tblAdminLeftPannel.Location = new System.Drawing.Point(3, 3);
            this.tblAdminLeftPannel.Name = "tblAdminLeftPannel";
            this.tblAdminLeftPannel.RowCount = 12;
            this.tblAdminLeftPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19.47174F));
            this.tblAdminLeftPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.052826F));
            this.tblAdminLeftPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.052826F));
            this.tblAdminLeftPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.052826F));
            this.tblAdminLeftPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.052826F));
            this.tblAdminLeftPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.052826F));
            this.tblAdminLeftPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.052826F));
            this.tblAdminLeftPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.052826F));
            this.tblAdminLeftPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.052826F));
            this.tblAdminLeftPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.052826F));
            this.tblAdminLeftPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.052826F));
            this.tblAdminLeftPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 47F));
            this.tblAdminLeftPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblAdminLeftPannel.Size = new System.Drawing.Size(253, 743);
            this.tblAdminLeftPannel.TabIndex = 0;
            // 
            // lblChangePassword
            // 
            this.lblChangePassword.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblChangePassword.AutoSize = true;
            this.lblChangePassword.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChangePassword.Location = new System.Drawing.Point(7, 654);
            this.lblChangePassword.Name = "lblChangePassword";
            this.lblChangePassword.Size = new System.Drawing.Size(239, 26);
            this.lblChangePassword.TabIndex = 11;
            this.lblChangePassword.Text = "ChangePassword";
            // 
            // lblSearchProduct
            // 
            this.lblSearchProduct.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblSearchProduct.AutoSize = true;
            this.lblSearchProduct.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchProduct.Location = new System.Drawing.Point(15, 542);
            this.lblSearchProduct.Name = "lblSearchProduct";
            this.lblSearchProduct.Size = new System.Drawing.Size(223, 26);
            this.lblSearchProduct.TabIndex = 8;
            this.lblSearchProduct.Text = "SEARCH PRODUCT";
            // 
            // lblMostSold
            // 
            this.lblMostSold.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblMostSold.AutoSize = true;
            this.lblMostSold.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMostSold.Location = new System.Drawing.Point(14, 486);
            this.lblMostSold.Name = "lblMostSold";
            this.lblMostSold.Size = new System.Drawing.Size(225, 26);
            this.lblMostSold.TabIndex = 7;
            this.lblMostSold.Text = "FAMOUS PRODUCT";
            // 
            // lblSortProduct
            // 
            this.lblSortProduct.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblSortProduct.AutoSize = true;
            this.lblSortProduct.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSortProduct.Location = new System.Drawing.Point(12, 430);
            this.lblSortProduct.Name = "lblSortProduct";
            this.lblSortProduct.Size = new System.Drawing.Size(228, 26);
            this.lblSortProduct.TabIndex = 6;
            this.lblSortProduct.Text = "SORTING PRODUCT";
            // 
            // lblAddDiscount
            // 
            this.lblAddDiscount.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblAddDiscount.AutoSize = true;
            this.lblAddDiscount.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddDiscount.Location = new System.Drawing.Point(35, 374);
            this.lblAddDiscount.Name = "lblAddDiscount";
            this.lblAddDiscount.Size = new System.Drawing.Size(182, 26);
            this.lblAddDiscount.TabIndex = 5;
            this.lblAddDiscount.Text = "ADD DISCOUNT";
            // 
            // lblViewProduct
            // 
            this.lblViewProduct.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblViewProduct.AutoSize = true;
            this.lblViewProduct.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblViewProduct.Location = new System.Drawing.Point(33, 318);
            this.lblViewProduct.Name = "lblViewProduct";
            this.lblViewProduct.Size = new System.Drawing.Size(187, 26);
            this.lblViewProduct.TabIndex = 4;
            this.lblViewProduct.Text = "VIEW PRODUCT";
            // 
            // lblUpdateProduct
            // 
            this.lblUpdateProduct.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblUpdateProduct.AutoSize = true;
            this.lblUpdateProduct.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUpdateProduct.Location = new System.Drawing.Point(15, 262);
            this.lblUpdateProduct.Name = "lblUpdateProduct";
            this.lblUpdateProduct.Size = new System.Drawing.Size(223, 26);
            this.lblUpdateProduct.TabIndex = 3;
            this.lblUpdateProduct.Text = "UPDATE PRODUCT";
            // 
            // lblDeleteProduct
            // 
            this.lblDeleteProduct.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblDeleteProduct.AutoSize = true;
            this.lblDeleteProduct.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDeleteProduct.Location = new System.Drawing.Point(17, 206);
            this.lblDeleteProduct.Name = "lblDeleteProduct";
            this.lblDeleteProduct.Size = new System.Drawing.Size(219, 26);
            this.lblDeleteProduct.TabIndex = 2;
            this.lblDeleteProduct.Text = "DELETE PRODUCT";
            // 
            // lblAddProduct
            // 
            this.lblAddProduct.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblAddProduct.AutoSize = true;
            this.lblAddProduct.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddProduct.Location = new System.Drawing.Point(38, 150);
            this.lblAddProduct.Name = "lblAddProduct";
            this.lblAddProduct.Size = new System.Drawing.Size(176, 26);
            this.lblAddProduct.TabIndex = 1;
            this.lblAddProduct.Text = "ADD PRODUCT";
            // 
            // lblExit
            // 
            this.lblExit.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblExit.AutoSize = true;
            this.lblExit.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExit.Location = new System.Drawing.Point(92, 706);
            this.lblExit.Name = "lblExit";
            this.lblExit.Size = new System.Drawing.Size(69, 26);
            this.lblExit.TabIndex = 10;
            this.lblExit.Text = "EXIT";
            // 
            // lblReviews
            // 
            this.lblReviews.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblReviews.AutoSize = true;
            this.lblReviews.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReviews.Location = new System.Drawing.Point(15, 598);
            this.lblReviews.Name = "lblReviews";
            this.lblReviews.Size = new System.Drawing.Size(222, 26);
            this.lblReviews.TabIndex = 9;
            this.lblReviews.Text = "VIEW FEEDBACKS";
            // 
            // pbAdminLogo
            // 
            this.pbAdminLogo.BackgroundImage = global::LOGIN__GMS.Properties.Resources.logo3;
            this.pbAdminLogo.Image = global::LOGIN__GMS.Properties.Resources.M1_removebg_preview;
            this.pbAdminLogo.Location = new System.Drawing.Point(3, 3);
            this.pbAdminLogo.Name = "pbAdminLogo";
            this.pbAdminLogo.Size = new System.Drawing.Size(247, 129);
            this.pbAdminLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbAdminLogo.TabIndex = 12;
            this.pbAdminLogo.TabStop = false;
            // 
            // tblAdmin
            // 
            this.tblAdmin.ColumnCount = 1;
            this.tblAdmin.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblAdmin.Location = new System.Drawing.Point(262, 3);
            this.tblAdmin.Name = "tblAdmin";
            this.tblAdmin.RowCount = 1;
            this.tblAdmin.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblAdmin.Size = new System.Drawing.Size(1252, 743);
            this.tblAdmin.TabIndex = 1;
            // 
            // frmAdminMainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1517, 749);
            this.Controls.Add(this.tblAdminFirstPannel);
            this.Name = "frmAdminMainMenu";
            this.Text = "Form2";
            this.tblAdminFirstPannel.ResumeLayout(false);
            this.tblAdminLeftPannel.ResumeLayout(false);
            this.tblAdminLeftPannel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbAdminLogo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tblAdminFirstPannel;
        private System.Windows.Forms.TableLayoutPanel tblAdminLeftPannel;
        private System.Windows.Forms.Label lblAddProduct;
        private System.Windows.Forms.Label lblChangePassword;
        private System.Windows.Forms.Label lblSearchProduct;
        private System.Windows.Forms.Label lblMostSold;
        private System.Windows.Forms.Label lblSortProduct;
        private System.Windows.Forms.Label lblAddDiscount;
        private System.Windows.Forms.Label lblViewProduct;
        private System.Windows.Forms.Label lblUpdateProduct;
        private System.Windows.Forms.Label lblDeleteProduct;
        private System.Windows.Forms.Label lblExit;
        private System.Windows.Forms.Label lblReviews;
        private System.Windows.Forms.PictureBox pbAdminLogo;
        private System.Windows.Forms.TableLayoutPanel tblAdmin;
    }
}