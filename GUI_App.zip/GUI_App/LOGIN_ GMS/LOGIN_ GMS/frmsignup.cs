﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LOGIN__GMS.BL;
using LOGIN__GMS.DL;
namespace LOGIN__GMS
{
    public partial class frmSignUp : Form
    {
        public frmSignUp()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Register_button_Click(object sender, EventArgs e)
        {
            DataDL.SetSignUpObject(TakeInputWithRoleSignUp());
            if(DataDL.GetSignUpObject() != null)
            {
                MUser signUp_User = DataDL.GetSignUpObject();
                MUserDL.addUserIntoList(signUp_User);
                if (signUp_User.getRole() == "customer")
                {
                    CustomerDL.addCustomerInList(new Customer(signUp_User.getName(), signUp_User.getPassword(), signUp_User.getRole()));
                }
                MUserDL.storeUserIntoFile(DataDL.GetSignUpObject(), DataDL.GetUsersPath());
                frmSignIn form = new frmSignIn();
                form.Show();
                this.Hide();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private MUser TakeInputWithRoleSignUp()
        {
            string name = txtName.Text;
            //bool checkName = Validations.CheckName();
            //if (CheckName == true)
            //{
            string password = txtPassword.Text;
            //bool CheckPassword = Validations.CheckPassword();
            //if(CheckPassword == true)
            //{
            string role = txtRole.Text;
            if(name != null && password !=null && role !=null)
            {
                if(role == "Customer" || role == "customer")
                {
                    Customer user = new Customer(name, password, role);
                    MessageBox.Show("SignedUp Successfully");
                    return user;
                }
                if(role == "Admin" || role == "admin")
                {
                    Admin user = new Admin(name, password, role);
                    MessageBox.Show("SignedUp Successfully");
                    return user;
                }
                else
                {
                    MessageBox.Show("SignUp Failed");
                }
            }
            return null;
            //}
            //}
        }
    }
}
