﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LOGIN__GMS.BL;

namespace LOGIN__GMS.DL
{
    class CustomerDL
    {
        private static List<Customer> customersList = new List<Customer>();//List of Customer's Info
        public static void addCustomerInList(Customer temp)//Function to Store  Data In List
        {
            customersList.Add(temp);
        }

        public static List<Customer> GetCustomerList()
        {
            return customersList;
        }
    }
}
