﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LOGIN__GMS.BL
{
    public class MUser
    {
        protected string userName;
        protected string userPassword;
        protected string userRole;

        public MUser()
        {

        }

        public MUser(string userName, string userPassword, string userRole)
        {
            this.userName = userName;
            this.userPassword = userPassword;
            this.userRole = userRole;
        }

        public MUser(string userName, string userPassword)
        {
            this.userName = userName;
            this.userPassword = userPassword;
            this.userRole = "NA";
        }

        public string getName()
        {
            return userName;
        }
        public string getPassword()
        {
            return userPassword;
        }

        public bool isAdmin()
        {
            if (userRole == "Admin")
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public virtual void setRole(string role)
        {
            this.userRole = "";
        }

        //Return Role of the Admin
        public virtual string getRole()
        {
            return null;
        }
    }
}
