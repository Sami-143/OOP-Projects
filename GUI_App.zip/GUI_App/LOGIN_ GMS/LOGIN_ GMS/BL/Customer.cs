﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LOGIN__GMS.BL
{
    class Customer : MUser
    {
        public Customer(string name, string password, string role) : base(name, password, role)//Constructors for the Customers Input
        {
        }

        public override void setRole(string role)
        {
            this.userRole = "customer";
        }
        public override string getRole()
        {
            return userRole;
        }
    }
}
