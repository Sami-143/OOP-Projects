﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LOGIN__GMS.BL
{
    class Admin : MUser
    {
        public Admin(string name, string password) : base(name, password)//Constructors for taking the name and Password as a parameter from pArent Class
        {
            this.userName = name;
            this.userPassword = password;
        }

        public Admin(string name, string password, string role) : base(name, password, role)//Constructors for initiallizing the List
        {
            
        }
        public Admin() : base()
        {

        }
        public override void setRole(string role)
        {
            this.userRole = "admin";
        }

        //Return Role of the Admin
        public override string getRole()
        {
            return userRole;
        }
    }
}
