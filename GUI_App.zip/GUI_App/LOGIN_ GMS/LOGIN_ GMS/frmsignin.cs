﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LOGIN__GMS.BL;
using LOGIN__GMS.DL;

namespace LOGIN__GMS
{
    public partial class frmSignIn : Form
    {
        public frmSignIn()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void cmd_Login_Click(object sender, EventArgs e)
        {
            DataDL.SetSignInObject(takeInputWithRoleSignIn());
            if (DataDL.GetSignInObject() != null)
            {
                DataDL.SetSignInObject(MUserDL.SignIn(DataDL.GetSignInObject()));
                if(DataDL.GetSignInObject() == null)
                {
                    MessageBox.Show("InValid Command");
                }
                else if(DataDL.GetSignInObject().isAdmin())
                {
                    MessageBox.Show("Welcome to Admin Menu");
                }
            }    
        }

        private MUser takeInputWithRoleSignIn()
        {
            string name = txtName1.Text;
            //bool checkName = Validations.CheckName();
            //if (CheckName == true)
            //{
            string password = txtPassword1.Text;
            //bool CheckPassword = Validations.CheckPassword();
            //if(CheckPassword == true)
            //{
            if (name != null && password != null)
            {
                MUser user = new MUser(name, password);
                return user;
            }
            return null;


        }
    }
}
