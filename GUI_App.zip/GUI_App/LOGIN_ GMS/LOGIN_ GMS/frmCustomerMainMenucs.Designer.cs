﻿
namespace LOGIN__GMS
{
    partial class frmCustomerMainMenucs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tblCustomerFirstPannel = new System.Windows.Forms.TableLayoutPanel();
            this.tblCustomerLeftPannel = new System.Windows.Forms.TableLayoutPanel();
            this.lblChangePasswordCus = new System.Windows.Forms.Label();
            this.lblBill = new System.Windows.Forms.Label();
            this.lblRemoveCart = new System.Windows.Forms.Label();
            this.lblViewProductCus = new System.Windows.Forms.Label();
            this.lblAddCart = new System.Windows.Forms.Label();
            this.lblPopularProduct = new System.Windows.Forms.Label();
            this.lblAddInfo = new System.Windows.Forms.Label();
            this.lblGiveReviews = new System.Windows.Forms.Label();
            this.pbCustomerlogo = new System.Windows.Forms.PictureBox();
            this.lblCusExit = new System.Windows.Forms.Label();
            this.tblCustomer = new System.Windows.Forms.TableLayoutPanel();
            this.tblCustomerFirstPannel.SuspendLayout();
            this.tblCustomerLeftPannel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbCustomerlogo)).BeginInit();
            this.SuspendLayout();
            // 
            // tblCustomerFirstPannel
            // 
            this.tblCustomerFirstPannel.ColumnCount = 2;
            this.tblCustomerFirstPannel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.10526F));
            this.tblCustomerFirstPannel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 82.89474F));
            this.tblCustomerFirstPannel.Controls.Add(this.tblCustomerLeftPannel, 0, 0);
            this.tblCustomerFirstPannel.Controls.Add(this.tblCustomer, 1, 0);
            this.tblCustomerFirstPannel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblCustomerFirstPannel.Location = new System.Drawing.Point(0, 0);
            this.tblCustomerFirstPannel.Name = "tblCustomerFirstPannel";
            this.tblCustomerFirstPannel.RowCount = 1;
            this.tblCustomerFirstPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblCustomerFirstPannel.Size = new System.Drawing.Size(1510, 752);
            this.tblCustomerFirstPannel.TabIndex = 1;
            // 
            // tblCustomerLeftPannel
            // 
            this.tblCustomerLeftPannel.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.tblCustomerLeftPannel.ColumnCount = 1;
            this.tblCustomerLeftPannel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblCustomerLeftPannel.Controls.Add(this.lblCusExit, 0, 9);
            this.tblCustomerLeftPannel.Controls.Add(this.lblBill, 0, 6);
            this.tblCustomerLeftPannel.Controls.Add(this.lblRemoveCart, 0, 5);
            this.tblCustomerLeftPannel.Controls.Add(this.lblAddInfo, 0, 1);
            this.tblCustomerLeftPannel.Controls.Add(this.pbCustomerlogo, 0, 0);
            this.tblCustomerLeftPannel.Controls.Add(this.lblAddCart, 0, 4);
            this.tblCustomerLeftPannel.Controls.Add(this.lblPopularProduct, 0, 3);
            this.tblCustomerLeftPannel.Controls.Add(this.lblViewProductCus, 0, 2);
            this.tblCustomerLeftPannel.Controls.Add(this.lblChangePasswordCus, 0, 7);
            this.tblCustomerLeftPannel.Controls.Add(this.lblGiveReviews, 0, 8);
            this.tblCustomerLeftPannel.Dock = System.Windows.Forms.DockStyle.Left;
            this.tblCustomerLeftPannel.Location = new System.Drawing.Point(3, 3);
            this.tblCustomerLeftPannel.Name = "tblCustomerLeftPannel";
            this.tblCustomerLeftPannel.RowCount = 10;
            this.tblCustomerLeftPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19.47174F));
            this.tblCustomerLeftPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.052826F));
            this.tblCustomerLeftPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.052826F));
            this.tblCustomerLeftPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.052826F));
            this.tblCustomerLeftPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.052826F));
            this.tblCustomerLeftPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.052826F));
            this.tblCustomerLeftPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.052826F));
            this.tblCustomerLeftPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.052826F));
            this.tblCustomerLeftPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.052826F));
            this.tblCustomerLeftPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.052826F));
            this.tblCustomerLeftPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblCustomerLeftPannel.Size = new System.Drawing.Size(252, 746);
            this.tblCustomerLeftPannel.TabIndex = 0;
            // 
            // lblChangePasswordCus
            // 
            this.lblChangePasswordCus.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblChangePasswordCus.AutoSize = true;
            this.lblChangePasswordCus.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChangePasswordCus.Location = new System.Drawing.Point(6, 566);
            this.lblChangePasswordCus.Name = "lblChangePasswordCus";
            this.lblChangePasswordCus.Size = new System.Drawing.Size(239, 26);
            this.lblChangePasswordCus.TabIndex = 11;
            this.lblChangePasswordCus.Text = "ChangePassword";
            // 
            // lblBill
            // 
            this.lblBill.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblBill.AutoSize = true;
            this.lblBill.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBill.Location = new System.Drawing.Point(60, 501);
            this.lblBill.Name = "lblBill";
            this.lblBill.Size = new System.Drawing.Size(132, 26);
            this.lblBill.TabIndex = 6;
            this.lblBill.Text = "VIEW BILL";
            this.lblBill.Click += new System.EventHandler(this.lblSortProduct_Click);
            // 
            // lblRemoveCart
            // 
            this.lblRemoveCart.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblRemoveCart.AutoSize = true;
            this.lblRemoveCart.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRemoveCart.Location = new System.Drawing.Point(34, 436);
            this.lblRemoveCart.Name = "lblRemoveCart";
            this.lblRemoveCart.Size = new System.Drawing.Size(183, 26);
            this.lblRemoveCart.TabIndex = 5;
            this.lblRemoveCart.Text = "REMOVE CART";
            // 
            // lblViewProductCus
            // 
            this.lblViewProductCus.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblViewProductCus.AutoSize = true;
            this.lblViewProductCus.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblViewProductCus.Location = new System.Drawing.Point(32, 241);
            this.lblViewProductCus.Name = "lblViewProductCus";
            this.lblViewProductCus.Size = new System.Drawing.Size(187, 26);
            this.lblViewProductCus.TabIndex = 4;
            this.lblViewProductCus.Text = "VIEW PRODUCT";
            // 
            // lblAddCart
            // 
            this.lblAddCart.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblAddCart.AutoSize = true;
            this.lblAddCart.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddCart.Location = new System.Drawing.Point(40, 371);
            this.lblAddCart.Name = "lblAddCart";
            this.lblAddCart.Size = new System.Drawing.Size(171, 26);
            this.lblAddCart.TabIndex = 3;
            this.lblAddCart.Text = "ADD TO CART";
            // 
            // lblPopularProduct
            // 
            this.lblPopularProduct.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblPopularProduct.AutoSize = true;
            this.lblPopularProduct.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPopularProduct.Location = new System.Drawing.Point(32, 306);
            this.lblPopularProduct.Name = "lblPopularProduct";
            this.lblPopularProduct.Size = new System.Drawing.Size(188, 26);
            this.lblPopularProduct.TabIndex = 2;
            this.lblPopularProduct.Text = "POPULAR ITEM";
            // 
            // lblAddInfo
            // 
            this.lblAddInfo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblAddInfo.AutoSize = true;
            this.lblAddInfo.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddInfo.Location = new System.Drawing.Point(65, 176);
            this.lblAddInfo.Name = "lblAddInfo";
            this.lblAddInfo.Size = new System.Drawing.Size(121, 26);
            this.lblAddInfo.TabIndex = 1;
            this.lblAddInfo.Text = "ADD INFO";
            // 
            // lblGiveReviews
            // 
            this.lblGiveReviews.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblGiveReviews.AutoSize = true;
            this.lblGiveReviews.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGiveReviews.Location = new System.Drawing.Point(16, 631);
            this.lblGiveReviews.Name = "lblGiveReviews";
            this.lblGiveReviews.Size = new System.Drawing.Size(219, 26);
            this.lblGiveReviews.TabIndex = 9;
            this.lblGiveReviews.Text = "GIVE FEEDBACKS";
            // 
            // pbCustomerlogo
            // 
            this.pbCustomerlogo.BackgroundImage = global::LOGIN__GMS.Properties.Resources.logo3;
            this.pbCustomerlogo.Image = global::LOGIN__GMS.Properties.Resources.M1_removebg_preview;
            this.pbCustomerlogo.Location = new System.Drawing.Point(3, 3);
            this.pbCustomerlogo.Name = "pbCustomerlogo";
            this.pbCustomerlogo.Size = new System.Drawing.Size(246, 151);
            this.pbCustomerlogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbCustomerlogo.TabIndex = 12;
            this.pbCustomerlogo.TabStop = false;
            // 
            // lblCusExit
            // 
            this.lblCusExit.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblCusExit.AutoSize = true;
            this.lblCusExit.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCusExit.Location = new System.Drawing.Point(91, 698);
            this.lblCusExit.Name = "lblCusExit";
            this.lblCusExit.Size = new System.Drawing.Size(69, 26);
            this.lblCusExit.TabIndex = 13;
            this.lblCusExit.Text = "Exit";
            // 
            // tblCustomer
            // 
            this.tblCustomer.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.tblCustomer.ColumnCount = 1;
            this.tblCustomer.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblCustomer.Location = new System.Drawing.Point(261, 3);
            this.tblCustomer.Name = "tblCustomer";
            this.tblCustomer.RowCount = 1;
            this.tblCustomer.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblCustomer.Size = new System.Drawing.Size(1202, 746);
            this.tblCustomer.TabIndex = 1;
            this.tblCustomer.Paint += new System.Windows.Forms.PaintEventHandler(this.tblCustomer_Paint);
            // 
            // frmCustomerMainMenucs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1510, 752);
            this.Controls.Add(this.tblCustomerFirstPannel);
            this.Name = "frmCustomerMainMenucs";
            this.Text = "frmCustomerMainMenucs";
            this.tblCustomerFirstPannel.ResumeLayout(false);
            this.tblCustomerLeftPannel.ResumeLayout(false);
            this.tblCustomerLeftPannel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbCustomerlogo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tblCustomerFirstPannel;
        private System.Windows.Forms.TableLayoutPanel tblCustomerLeftPannel;
        private System.Windows.Forms.Label lblChangePasswordCus;
        private System.Windows.Forms.Label lblBill;
        private System.Windows.Forms.Label lblRemoveCart;
        private System.Windows.Forms.Label lblViewProductCus;
        private System.Windows.Forms.Label lblAddCart;
        private System.Windows.Forms.Label lblPopularProduct;
        private System.Windows.Forms.Label lblAddInfo;
        private System.Windows.Forms.Label lblGiveReviews;
        private System.Windows.Forms.PictureBox pbCustomerlogo;
        private System.Windows.Forms.Label lblCusExit;
        private System.Windows.Forms.TableLayoutPanel tblCustomer;
    }
}