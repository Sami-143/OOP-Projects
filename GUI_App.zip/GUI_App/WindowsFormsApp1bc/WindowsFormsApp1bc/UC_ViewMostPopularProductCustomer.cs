﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1bc.BL;
using WindowsFormsApp1bc.DL;

namespace WindowsFormsApp1bc
{
    public partial class UC_ViewMostPopularProductCustomer : UserControl
    {
        Customer customer;
        public UC_ViewMostPopularProductCustomer(Customer customer)
        {
            InitializeComponent();
            this.customer = customer;
        }

        private void btn_MostPopularProductCustomerBack_Click(object sender, EventArgs e)
        {
            Hide();
            frmCustomerMainMenu obj = new frmCustomerMainMenu(customer);
            obj.ShowDialog();
        }

        private void UC_ViewMostPopularProductCustomer_Load(object sender, EventArgs e)
        {
            pro_duct pro = PDataLayer.sortBySoldedItem();
            lblPopularName.Text += pro.Pro_Name;
            lblPopularQuantity.Text += pro.Most_sold;
        }
    }
}
