﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1bc.BL;
using WindowsFormsApp1bc.DL;

namespace WindowsFormsApp1bc
{
    public partial class UC_AddInfo : UserControl
    {
        bool check;
        Customer customer;
        public UC_AddInfo(Customer customer)
        {
            InitializeComponent();
            this.customer = customer;
        }

        private void btnAddToCart_Click(object sender, EventArgs e)
        {
            string email = txtMail.Text;
            string city = txtCity.Text;
            string contactNumber = txtContanct.Text;
            string id = txtID.Text;

            if (!IsValidEmail(email))
            {
                MessageBox.Show("Invalid email format. Please enter a valid email ending with '@gmail.com'.");
                return;
            }

            if (!IsValidContactNumber(contactNumber))
            {
                MessageBox.Show("Invalid contact number. Please enter an 11-digit number.");
                return;
            }
            customer.setMail(email);
            customer.setCity(city);
            customer.setID(id);
            customer.setContactNumber(contactNumber);

            MessageBox.Show("Information added successfully");
            removeDataFromTextBoxes();
            CustomerDL.store_Data_In_File_Customer(customer);

        }

        private bool IsValidEmail(string email)
        {
            // Check if the email ends with '@gmail.com'
            return email.EndsWith("@gmail.com", StringComparison.OrdinalIgnoreCase);
        }

        private bool IsValidContactNumber(string contactNumber)
        {
            // Check if the contact number has exactly 11 digits
            return contactNumber.Length == 11 && contactNumber.All(char.IsDigit);
        }

        private void removeDataFromTextBoxes()
        {
            txtMail.Text = string.Empty;
            txtCity.Text = string.Empty;
            txtID.Text = string.Empty;
            txtContanct.Text = string.Empty;
        }

        private void txtMail_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtCity_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void txtContanct_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtID_TextChanged(object sender, EventArgs e)
        {
            
        }

        static bool IsAlphabetic(string input)
        {
            // Loop through each character in the input string
            foreach (char c in input)
            {
                // Use Char.IsLetter() method to check if the character is an alphabet
                if (!Char.IsLetter(c))
                {
                    return false;
                }
            }
            return true;
        }

        private void btnAddInfoBack_Click(object sender, EventArgs e)
        {
            Hide();
            frmSignIn obj = new frmSignIn();
            obj.ShowDialog();
        }
    }
}
