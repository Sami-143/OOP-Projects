﻿
namespace WindowsFormsApp1bc
{
    partial class UC_AddProducts
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tblsecondAddPro = new System.Windows.Forms.TableLayoutPanel();
            this.txtAddProStock = new System.Windows.Forms.TextBox();
            this.txtAddProPrice = new System.Windows.Forms.TextBox();
            this.lblAddProStock = new System.Windows.Forms.Label();
            this.lblAddProPrice = new System.Windows.Forms.Label();
            this.lblAddDiscount = new System.Windows.Forms.Label();
            this.txtAddDiscount = new System.Windows.Forms.TextBox();
            this.AddProductButton = new System.Windows.Forms.Button();
            this.BackButtonToAdminMenu = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.chkBxLocal = new System.Windows.Forms.CheckBox();
            this.chkBxBranded = new System.Windows.Forms.CheckBox();
            this.lblValidationProductName = new System.Windows.Forms.Label();
            this.lblValidationProductPrice = new System.Windows.Forms.Label();
            this.lblValidationProductStock = new System.Windows.Forms.Label();
            this.lblValidationProductDiscount = new System.Windows.Forms.Label();
            this.btnViewProducts = new System.Windows.Forms.Button();
            this.lblAddProductName = new System.Windows.Forms.Label();
            this.tblMainAddPro = new System.Windows.Forms.TableLayoutPanel();
            this.lblAddProMain = new System.Windows.Forms.Label();
            this.txtAddProNames = new System.Windows.Forms.TextBox();
            this.tblsecondAddPro.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tblMainAddPro.SuspendLayout();
            this.SuspendLayout();
            // 
            // tblsecondAddPro
            // 
            this.tblsecondAddPro.BackColor = System.Drawing.Color.Transparent;
            this.tblsecondAddPro.ColumnCount = 3;
            this.tblsecondAddPro.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 52.56797F));
            this.tblsecondAddPro.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 47.43203F));
            this.tblsecondAddPro.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 107F));
            this.tblsecondAddPro.Controls.Add(this.txtAddProStock, 1, 2);
            this.tblsecondAddPro.Controls.Add(this.txtAddProPrice, 1, 1);
            this.tblsecondAddPro.Controls.Add(this.lblAddProStock, 0, 2);
            this.tblsecondAddPro.Controls.Add(this.lblAddProPrice, 0, 1);
            this.tblsecondAddPro.Controls.Add(this.lblAddDiscount, 0, 3);
            this.tblsecondAddPro.Controls.Add(this.txtAddDiscount, 1, 3);
            this.tblsecondAddPro.Controls.Add(this.AddProductButton, 1, 5);
            this.tblsecondAddPro.Controls.Add(this.BackButtonToAdminMenu, 0, 5);
            this.tblsecondAddPro.Controls.Add(this.label1, 0, 4);
            this.tblsecondAddPro.Controls.Add(this.tableLayoutPanel1, 1, 4);
            this.tblsecondAddPro.Controls.Add(this.lblValidationProductName, 2, 0);
            this.tblsecondAddPro.Controls.Add(this.lblValidationProductPrice, 2, 1);
            this.tblsecondAddPro.Controls.Add(this.lblValidationProductStock, 2, 2);
            this.tblsecondAddPro.Controls.Add(this.lblValidationProductDiscount, 2, 3);
            this.tblsecondAddPro.Controls.Add(this.btnViewProducts, 2, 5);
            this.tblsecondAddPro.Controls.Add(this.lblAddProductName, 0, 0);
            this.tblsecondAddPro.Controls.Add(this.txtAddProNames, 1, 0);
            this.tblsecondAddPro.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblsecondAddPro.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tblsecondAddPro.Location = new System.Drawing.Point(2, 144);
            this.tblsecondAddPro.Margin = new System.Windows.Forms.Padding(2);
            this.tblsecondAddPro.Name = "tblsecondAddPro";
            this.tblsecondAddPro.RowCount = 7;
            this.tblsecondAddPro.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.43932F));
            this.tblsecondAddPro.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.10169F));
            this.tblsecondAddPro.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.33898F));
            this.tblsecondAddPro.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 17.16102F));
            this.tblsecondAddPro.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 31.99153F));
            this.tblsecondAddPro.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 128F));
            this.tblsecondAddPro.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16F));
            this.tblsecondAddPro.Size = new System.Drawing.Size(849, 529);
            this.tblsecondAddPro.TabIndex = 0;
            this.tblsecondAddPro.Paint += new System.Windows.Forms.PaintEventHandler(this.tblsecondAddPro_Paint);
            // 
            // txtAddProStock
            // 
            this.txtAddProStock.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtAddProStock.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddProStock.Location = new System.Drawing.Point(422, 141);
            this.txtAddProStock.Margin = new System.Windows.Forms.Padding(2);
            this.txtAddProStock.Name = "txtAddProStock";
            this.txtAddProStock.Size = new System.Drawing.Size(286, 28);
            this.txtAddProStock.TabIndex = 6;
            this.txtAddProStock.TextChanged += new System.EventHandler(this.txtAddProStock_TextChanged);
            // 
            // txtAddProPrice
            // 
            this.txtAddProPrice.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtAddProPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddProPrice.Location = new System.Drawing.Point(422, 71);
            this.txtAddProPrice.Margin = new System.Windows.Forms.Padding(2);
            this.txtAddProPrice.Name = "txtAddProPrice";
            this.txtAddProPrice.Size = new System.Drawing.Size(286, 28);
            this.txtAddProPrice.TabIndex = 5;
            this.txtAddProPrice.TextChanged += new System.EventHandler(this.txtAddProPrice_TextChanged);
            // 
            // lblAddProStock
            // 
            this.lblAddProStock.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblAddProStock.AutoSize = true;
            this.lblAddProStock.Font = new System.Drawing.Font("Algerian", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddProStock.Location = new System.Drawing.Point(24, 140);
            this.lblAddProStock.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAddProStock.Name = "lblAddProStock";
            this.lblAddProStock.Size = new System.Drawing.Size(341, 30);
            this.lblAddProStock.TabIndex = 2;
            this.lblAddProStock.Text = "Enter Product Stock: ";
            // 
            // lblAddProPrice
            // 
            this.lblAddProPrice.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblAddProPrice.AutoSize = true;
            this.lblAddProPrice.Font = new System.Drawing.Font("Algerian", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddProPrice.Location = new System.Drawing.Point(28, 70);
            this.lblAddProPrice.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAddProPrice.Name = "lblAddProPrice";
            this.lblAddProPrice.Size = new System.Drawing.Size(333, 30);
            this.lblAddProPrice.TabIndex = 1;
            this.lblAddProPrice.Text = "Enter Product Price: ";
            // 
            // lblAddDiscount
            // 
            this.lblAddDiscount.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblAddDiscount.AutoSize = true;
            this.lblAddDiscount.Font = new System.Drawing.Font("Algerian", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddDiscount.Location = new System.Drawing.Point(4, 212);
            this.lblAddDiscount.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAddDiscount.Name = "lblAddDiscount";
            this.lblAddDiscount.Size = new System.Drawing.Size(382, 30);
            this.lblAddDiscount.TabIndex = 2;
            this.lblAddDiscount.Text = "Enter Product Discount: ";
            // 
            // txtAddDiscount
            // 
            this.txtAddDiscount.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtAddDiscount.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddDiscount.Location = new System.Drawing.Point(422, 213);
            this.txtAddDiscount.Margin = new System.Windows.Forms.Padding(2);
            this.txtAddDiscount.Name = "txtAddDiscount";
            this.txtAddDiscount.Size = new System.Drawing.Size(286, 28);
            this.txtAddDiscount.TabIndex = 6;
            this.txtAddDiscount.TextChanged += new System.EventHandler(this.txtAddDiscount_TextChanged);
            // 
            // AddProductButton
            // 
            this.AddProductButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.AddProductButton.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddProductButton.ForeColor = System.Drawing.Color.Black;
            this.AddProductButton.Location = new System.Drawing.Point(491, 421);
            this.AddProductButton.Margin = new System.Windows.Forms.Padding(2);
            this.AddProductButton.Name = "AddProductButton";
            this.AddProductButton.Size = new System.Drawing.Size(148, 52);
            this.AddProductButton.TabIndex = 7;
            this.AddProductButton.Text = "Add Product";
            this.AddProductButton.UseVisualStyleBackColor = true;
            this.AddProductButton.Click += new System.EventHandler(this.AddProductButton_Click);
            // 
            // BackButtonToAdminMenu
            // 
            this.BackButtonToAdminMenu.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.BackButtonToAdminMenu.BackColor = System.Drawing.Color.Black;
            this.BackButtonToAdminMenu.Font = new System.Drawing.Font("Algerian", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackButtonToAdminMenu.ForeColor = System.Drawing.Color.Transparent;
            this.BackButtonToAdminMenu.Location = new System.Drawing.Point(145, 425);
            this.BackButtonToAdminMenu.Margin = new System.Windows.Forms.Padding(2);
            this.BackButtonToAdminMenu.Name = "BackButtonToAdminMenu";
            this.BackButtonToAdminMenu.Size = new System.Drawing.Size(99, 44);
            this.BackButtonToAdminMenu.TabIndex = 7;
            this.BackButtonToAdminMenu.Text = "Back";
            this.BackButtonToAdminMenu.UseVisualStyleBackColor = false;
            this.BackButtonToAdminMenu.Click += new System.EventHandler(this.BackButtonToAdminMenu_Click);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Algerian", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(59, 306);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(271, 30);
            this.label1.TabIndex = 2;
            this.label1.Text = "Enter Category: ";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 202F));
            this.tableLayoutPanel1.Controls.Add(this.chkBxLocal, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.chkBxBranded, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(392, 262);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(2);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(347, 119);
            this.tableLayoutPanel1.TabIndex = 8;
            // 
            // chkBxLocal
            // 
            this.chkBxLocal.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.chkBxLocal.AutoSize = true;
            this.chkBxLocal.Font = new System.Drawing.Font("Algerian", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBxLocal.Location = new System.Drawing.Point(207, 49);
            this.chkBxLocal.Margin = new System.Windows.Forms.Padding(2);
            this.chkBxLocal.Name = "chkBxLocal";
            this.chkBxLocal.Size = new System.Drawing.Size(77, 20);
            this.chkBxLocal.TabIndex = 1;
            this.chkBxLocal.Text = "Local";
            this.chkBxLocal.UseVisualStyleBackColor = true;
            // 
            // chkBxBranded
            // 
            this.chkBxBranded.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.chkBxBranded.AutoSize = true;
            this.chkBxBranded.Font = new System.Drawing.Font("Algerian", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBxBranded.Location = new System.Drawing.Point(22, 49);
            this.chkBxBranded.Margin = new System.Windows.Forms.Padding(2);
            this.chkBxBranded.Name = "chkBxBranded";
            this.chkBxBranded.Size = new System.Drawing.Size(101, 20);
            this.chkBxBranded.TabIndex = 0;
            this.chkBxBranded.Text = "Branded";
            this.chkBxBranded.UseVisualStyleBackColor = true;
            // 
            // lblValidationProductName
            // 
            this.lblValidationProductName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblValidationProductName.AutoSize = true;
            this.lblValidationProductName.Font = new System.Drawing.Font("Algerian", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValidationProductName.Location = new System.Drawing.Point(795, 21);
            this.lblValidationProductName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblValidationProductName.Name = "lblValidationProductName";
            this.lblValidationProductName.Size = new System.Drawing.Size(0, 12);
            this.lblValidationProductName.TabIndex = 9;
            this.lblValidationProductName.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lblValidationProductPrice
            // 
            this.lblValidationProductPrice.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblValidationProductPrice.AutoSize = true;
            this.lblValidationProductPrice.Font = new System.Drawing.Font("Algerian", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValidationProductPrice.Location = new System.Drawing.Point(795, 79);
            this.lblValidationProductPrice.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblValidationProductPrice.Name = "lblValidationProductPrice";
            this.lblValidationProductPrice.Size = new System.Drawing.Size(0, 12);
            this.lblValidationProductPrice.TabIndex = 9;
            this.lblValidationProductPrice.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lblValidationProductStock
            // 
            this.lblValidationProductStock.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblValidationProductStock.AutoSize = true;
            this.lblValidationProductStock.Font = new System.Drawing.Font("Algerian", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValidationProductStock.Location = new System.Drawing.Point(795, 149);
            this.lblValidationProductStock.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblValidationProductStock.Name = "lblValidationProductStock";
            this.lblValidationProductStock.Size = new System.Drawing.Size(0, 12);
            this.lblValidationProductStock.TabIndex = 9;
            this.lblValidationProductStock.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lblValidationProductDiscount
            // 
            this.lblValidationProductDiscount.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblValidationProductDiscount.AutoSize = true;
            this.lblValidationProductDiscount.Font = new System.Drawing.Font("Algerian", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValidationProductDiscount.Location = new System.Drawing.Point(795, 221);
            this.lblValidationProductDiscount.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblValidationProductDiscount.Name = "lblValidationProductDiscount";
            this.lblValidationProductDiscount.Size = new System.Drawing.Size(0, 12);
            this.lblValidationProductDiscount.TabIndex = 9;
            this.lblValidationProductDiscount.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // btnViewProducts
            // 
            this.btnViewProducts.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnViewProducts.BackColor = System.Drawing.Color.Black;
            this.btnViewProducts.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewProducts.Location = new System.Drawing.Point(752, 423);
            this.btnViewProducts.Margin = new System.Windows.Forms.Padding(2);
            this.btnViewProducts.Name = "btnViewProducts";
            this.btnViewProducts.Size = new System.Drawing.Size(86, 48);
            this.btnViewProducts.TabIndex = 10;
            this.btnViewProducts.Text = "View";
            this.btnViewProducts.UseVisualStyleBackColor = false;
            // 
            // lblAddProductName
            // 
            this.lblAddProductName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblAddProductName.AutoSize = true;
            this.lblAddProductName.Font = new System.Drawing.Font("Algerian", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddProductName.Location = new System.Drawing.Point(29, 12);
            this.lblAddProductName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAddProductName.Name = "lblAddProductName";
            this.lblAddProductName.Size = new System.Drawing.Size(331, 30);
            this.lblAddProductName.TabIndex = 0;
            this.lblAddProductName.Text = "Enter Product Name: ";
            // 
            // tblMainAddPro
            // 
            this.tblMainAddPro.BackgroundImage = global::WindowsFormsApp1bc.Properties.Resources.Garmentt1;
            this.tblMainAddPro.ColumnCount = 1;
            this.tblMainAddPro.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblMainAddPro.Controls.Add(this.lblAddProMain, 0, 0);
            this.tblMainAddPro.Controls.Add(this.tblsecondAddPro, 0, 1);
            this.tblMainAddPro.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblMainAddPro.Location = new System.Drawing.Point(0, 0);
            this.tblMainAddPro.Margin = new System.Windows.Forms.Padding(2);
            this.tblMainAddPro.Name = "tblMainAddPro";
            this.tblMainAddPro.RowCount = 2;
            this.tblMainAddPro.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 21.03825F));
            this.tblMainAddPro.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 78.96175F));
            this.tblMainAddPro.Size = new System.Drawing.Size(853, 675);
            this.tblMainAddPro.TabIndex = 2;
            // 
            // lblAddProMain
            // 
            this.lblAddProMain.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblAddProMain.AutoSize = true;
            this.lblAddProMain.Font = new System.Drawing.Font("Algerian", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddProMain.Location = new System.Drawing.Point(289, 50);
            this.lblAddProMain.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAddProMain.Name = "lblAddProMain";
            this.lblAddProMain.Size = new System.Drawing.Size(274, 42);
            this.lblAddProMain.TabIndex = 1;
            this.lblAddProMain.Text = "ADD PRODUCT";
            // 
            // txtAddProNames
            // 
            this.txtAddProNames.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtAddProNames.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddProNames.Location = new System.Drawing.Point(422, 13);
            this.txtAddProNames.Margin = new System.Windows.Forms.Padding(2);
            this.txtAddProNames.Name = "txtAddProNames";
            this.txtAddProNames.Size = new System.Drawing.Size(286, 28);
            this.txtAddProNames.TabIndex = 11;
            // 
            // UC_AddProducts
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tblMainAddPro);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "UC_AddProducts";
            this.Size = new System.Drawing.Size(853, 675);
            this.tblsecondAddPro.ResumeLayout(false);
            this.tblsecondAddPro.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tblMainAddPro.ResumeLayout(false);
            this.tblMainAddPro.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tblsecondAddPro;
        private System.Windows.Forms.TextBox txtAddProStock;
        private System.Windows.Forms.TextBox txtAddProPrice;
        private System.Windows.Forms.Label lblAddProductName;
        private System.Windows.Forms.Label lblAddProStock;
        private System.Windows.Forms.Label lblAddProPrice;
        private System.Windows.Forms.TableLayoutPanel tblMainAddPro;
        private System.Windows.Forms.Label lblAddProMain;
        private System.Windows.Forms.Button AddProductButton;
        private System.Windows.Forms.Button BackButtonToAdminMenu;
        private System.Windows.Forms.Label lblAddDiscount;
        private System.Windows.Forms.TextBox txtAddDiscount;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.CheckBox chkBxLocal;
        private System.Windows.Forms.CheckBox chkBxBranded;
        private System.Windows.Forms.Label lblValidationProductName;
        private System.Windows.Forms.Label lblValidationProductPrice;
        private System.Windows.Forms.Label lblValidationProductStock;
        private System.Windows.Forms.Label lblValidationProductDiscount;
        private System.Windows.Forms.Button btnViewProducts;
        private System.Windows.Forms.TextBox txtAddProNames;
    }
}
