﻿
namespace WindowsFormsApp1bc
{
    partial class UC_SortingProduct
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tblSorting = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.dtaGrdSorting = new System.Windows.Forms.DataGridView();
            this.tblSorting.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtaGrdSorting)).BeginInit();
            this.SuspendLayout();
            // 
            // tblSorting
            // 
            this.tblSorting.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.tblSorting.ColumnCount = 1;
            this.tblSorting.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblSorting.Controls.Add(this.label1, 0, 0);
            this.tblSorting.Controls.Add(this.dtaGrdSorting, 0, 1);
            this.tblSorting.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblSorting.Location = new System.Drawing.Point(0, 0);
            this.tblSorting.Name = "tblSorting";
            this.tblSorting.RowCount = 2;
            this.tblSorting.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.53333F));
            this.tblSorting.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 83.46667F));
            this.tblSorting.Size = new System.Drawing.Size(1217, 750);
            this.tblSorting.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Algerian", 26F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(314, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(588, 49);
            this.label1.TabIndex = 0;
            this.label1.Text = "Most Expensive Product";
            // 
            // dtaGrdSorting
            // 
            this.dtaGrdSorting.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtaGrdSorting.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dtaGrdSorting.Location = new System.Drawing.Point(3, 126);
            this.dtaGrdSorting.Name = "dtaGrdSorting";
            this.dtaGrdSorting.RowHeadersWidth = 51;
            this.dtaGrdSorting.RowTemplate.Height = 24;
            this.dtaGrdSorting.Size = new System.Drawing.Size(1211, 621);
            this.dtaGrdSorting.TabIndex = 1;
            // 
            // UC_SortingProduct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tblSorting);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "UC_SortingProduct";
            this.Size = new System.Drawing.Size(1217, 750);
            this.Load += new System.EventHandler(this.UC_SortingProduct_Load);
            this.tblSorting.ResumeLayout(false);
            this.tblSorting.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtaGrdSorting)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tblSorting;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dtaGrdSorting;
    }
}
