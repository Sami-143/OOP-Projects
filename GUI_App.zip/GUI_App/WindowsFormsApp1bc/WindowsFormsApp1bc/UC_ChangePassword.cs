﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1bc.BL;
using WindowsFormsApp1bc.DL;

namespace WindowsFormsApp1bc
{
    public partial class UC_ChangePassword : UserControl
    {
        Admin admin;
        bool Check;


        public UC_ChangePassword(Admin admin)
        {
            InitializeComponent();
            this.admin = admin;
        }

        private void btnChangePassword_Click(object sender, EventArgs e)
        {
            if (txtOldPassword.Text != string.Empty)
            {
                if (txtOldPassword.Text == admin.getPassword())
                {
                    if (txtNewPassword.Text == txtConfirmPassword.Text)
                    {
                        if (IsPasswordValid(txtNewPassword.Text))
                        {
                            admin.setPassword(txtConfirmPassword.Text);
                            MUserDL.storeDataInFile();
                            MessageBox.Show("Password changed successfully");
                        }
                        else
                        {
                            MessageBox.Show("New password must be 8 characters long and contain at least 1 special character, 1 numeric digit, and 1 alphabetic character.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("New and confirm password mismatches");
                    }
                }
                else
                {
                    MessageBox.Show("Please input correct old password");
                }
            }
            else
            {
                MessageBox.Show("Please enter something");
            }
        }

        private void txtOldPassword_TextChanged(object sender, EventArgs e)
        {
            Check = IsPasswordValid(txtOldPassword.Text);
            if (Check == true)
            {
                lblValidationOldPass.ForeColor = Color.Green;
                lblValidationOldPass.Text = "Valid";
            }
            else
            {
                lblValidationOldPass.ForeColor = Color.Red;
                lblValidationOldPass.Text = "Password 8 Character & Digits & Special Character";
            }
        }

        private void txtNewPassword_TextChanged(object sender, EventArgs e)
        {
            Check = IsPasswordValid(txtNewPassword.Text);
            if (Check == true)
            {
                lblValidationNewPass.ForeColor = Color.Green;
                lblValidationNewPass.Text = "Valid";
            }
            else
            {
                lblValidationNewPass.ForeColor = Color.Red;
                lblValidationNewPass.Text = "Password 8 Character & Digits & Special Charcter";
            }
        }

        private void txtConfirmPassword_TextChanged(object sender, EventArgs e)
        {
            Check = IsPasswordValid(txtConfirmPassword.Text);
            if (Check == true)
            {
                lblValidationConfirmPass.ForeColor = Color.Green;
                lblValidationConfirmPass.Text = "Valid";
            }
            else
            {
                lblValidationConfirmPass.ForeColor = Color.Red;
                lblValidationConfirmPass.Text = "Password 8 Character & Digits & Special Character";
            }

        }

        static bool IsPasswordValid(string password)
        {
            if (password.Length < 8)
            {
                return false;
            }

            // Check if the password contains at least one alphabetic character, one number, and one special character
            bool containsAlphabeticChar = false;
            bool containsNumber = false;
            bool containsSpecialChar = false;

            foreach (char c in password)
            {
                if (char.IsLetter(c))
                {
                    containsAlphabeticChar = true;
                }
                else if (char.IsDigit(c))
                {
                    containsNumber = true;
                }
                else if (char.IsSymbol(c) || char.IsPunctuation(c))
                {
                    containsSpecialChar = true;
                }

                // If all conditions are met, no need to check further
                if (containsAlphabeticChar && containsNumber && containsSpecialChar)
                {
                    break;
                }
            }

            // Return true if all conditions are met (valid password), otherwise false
            return containsAlphabeticChar && containsNumber && containsSpecialChar;

        }
    }
}
