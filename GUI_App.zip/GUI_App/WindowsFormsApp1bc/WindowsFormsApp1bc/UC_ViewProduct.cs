﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1bc.DL;
using WindowsFormsApp1bc.BL;
namespace WindowsFormsApp1bc
{
    public partial class UC_ViewProduct : UserControl
    {
        pro_duct selectedProduct;
        public UC_ViewProduct()
        {
            InitializeComponent();
        }
        private void UC_ViewProduct_Load(object sender, EventArgs e)
        {
            dataBind();
        }

        private void dtaGrdCrud_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            pro_duct p = (pro_duct)dtaGrdCrud.CurrentRow.DataBoundItem;
            selectedProduct = p;
            loadDataInTextBoxes();
        }

        private void dataBind()
        {
            dtaGrdCrud.DataSource = null;
            dtaGrdCrud.DataSource = PDataLayer.getProducts();
            dtaGrdCrud.Refresh();
        }

        private void loadDataInTextBoxes()
        {
            txtName.Text = selectedProduct.Pro_Name;
            txtPrice.Text = selectedProduct.Pro_Price.ToString();
            txtStock.Text = selectedProduct.Pro_Stock.ToString();
            txtDiscount.Text = selectedProduct.Discount.ToString();
        }

        private void removeDataFromTextBoxes()
        {
            txtName.Text = string.Empty;
            txtPrice.Text = string.Empty;
            txtStock.Text = string.Empty;
            txtDiscount.Text = string.Empty;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if(selectedProduct != null)
            {
                PDataLayer.RemoveProduct(selectedProduct);
                MessageBox.Show("Deleted Sucessfully");
                removeDataFromTextBoxes();
                dataBind();
                selectedProduct = null;
                PDataLayer.store_Data_In_File();
            }
            else
            {
                MessageBox.Show("Nothing selected");
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (selectedProduct != null)
            {
                pro_duct p = new pro_duct(txtName.Text, double.Parse(txtPrice.Text), int.Parse(txtStock.Text),double.Parse(txtDiscount.Text));
                PDataLayer.UpdateProduct(selectedProduct, p);
                MessageBox.Show("Updated Sucessfully");
                removeDataFromTextBoxes();
                dataBind();
                selectedProduct = null;
                PDataLayer.store_Data_In_File();
            }
            else
            {
                MessageBox.Show("Nothing selected");
            }
        }
    }
}
