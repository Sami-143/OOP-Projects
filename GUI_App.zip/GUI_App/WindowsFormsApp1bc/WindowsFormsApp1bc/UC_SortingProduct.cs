﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1bc.DL;

namespace WindowsFormsApp1bc
{
    public partial class UC_SortingProduct : UserControl
    {
        public UC_SortingProduct()
        {
            InitializeComponent();
        }

        private void UC_SortingProduct_Load(object sender, EventArgs e)
        {
            dtaGrdSorting.DataSource = null;
            dtaGrdSorting.DataSource = PDataLayer.sortByPrice();
            dtaGrdSorting.Refresh();
        }
    }
}
