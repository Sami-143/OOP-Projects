﻿using WindowsFormsApp1bc.BL;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1bc.DL
{
    class MUserDL//Data LAyer of the MUser
    {
        public static List<MUser> users = new List<MUser>();//List for storing the Users
        public static bool readData(string path)//ReadDAta of the Users from the File
        {
            if (File.Exists(path))
            {
                StreamReader fileVariable = new StreamReader("Data.txt");
                string record;
                while ((record = fileVariable.ReadLine()) != null)
                {
                    string name = parseData(record, 1);
                    string password = parseData(record, 2);
                    string role = parseData(record, 3);
                    if (role == "customer" || role == "Customer")
                    {
                        Customer c = new Customer(name, password, role);
                        CustomerDL.addCustomerInList(new Customer(name, password, role));
                        storeDataInList(c);
                    }
                    else if (role == "Admin" || role == "admin")
                    {
                        Admin a = new Admin(name, password, role);
                        storeDataInList(a);
                    }
                }
                fileVariable.Close();
                return true;
            }
            return false;
        }

        public static string parseData(string record, int field)//Function for using the Comma Count to read tge Data From the File
        {
            int comma = 1;
            string item = "";
            for (int x = 0; x < record.Length;
            x++)
            {
                if (record[x] == ',')
                {
                    comma++;
                }
                else if (comma == field)
                {
                    item = item + record[x];
                }
            }
            return item;
        }
        public static MUser signIn(MUser user)//Function for signIn As a User 
        {
            foreach (var storedUser in users)
            {
                if (user.getName() == storedUser.getName() && user.getPassword() == storedUser.getPassword())
                {
                    return storedUser;
                }
            }
            return null;
        }
        public static void storeDataInList(MUser user)//Funtion for storing the Data in File
        {
            users.Add(user);
        }

        public static void storeDataInFile(string path, MUser user)//Funtion for storing the Data in List
        {
            StreamWriter file = new StreamWriter("Data.txt",true);
            file.WriteLine(user.getName() + "," + user.getPassword() + "," + user.getRole());
            file.Flush();
            file.Close();
        }
        public static void storeDataInFile()//Funtion for storing the Data in List
        {
            StreamWriter file = new StreamWriter("Data.txt",true);
            foreach (var user in users)
            {
                file.WriteLine(user.getName() + "," + user.getPassword() + "," + user.getRole());
            }
            file.Flush();
            file.Close();
        }


        public static void GetPathforUsersFile()
        {
            DataDL.SetUsersPath("Data.txt");
        }
        

    }
}
