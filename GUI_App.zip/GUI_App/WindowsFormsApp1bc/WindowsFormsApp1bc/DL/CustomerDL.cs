﻿using WindowsFormsApp1bc.DL;
using WindowsFormsApp1bc.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace WindowsFormsApp1bc.DL
{
    class CustomerDL
    {
        private static List<Customer> customersList = new List<Customer>();//List of Customer's Info
        public static void addCustomerInList(Customer temp)//Function to Store  Data In List
        {
            customersList.Add(temp);
        }

        public static List<Customer> GetCustomerList()
        {
            return customersList;
        }
        public static int getLengthOfCustomerList()
        {
            return customersList.Count();
        }
        
        //get object by product name

        public static string GetCustomerID()
        {
            Random random = new Random();
            int customerId = random.Next(1000, 10000);
            return customerId.ToString();
        }
        public static Customer getParticularCustomer(string name)
        {
            foreach (Customer c in customersList)
            {   
                if(c.getName() == name)
                {
                    return c;
                }
            }
            return null;
        }
        public static void editCustomer(Customer c,string id,string address,string mail,string city,string contactNumber)
        {
            c.setID(id);
            c.setAddress(address);
            c.setMail(mail);
            c.setCity(city);
            c.setContactNumber(contactNumber);
        }

        public static bool readCustomerDataInFile(string path)
        {
            if (File.Exists(path))
            {
                StreamReader fileVariable = new StreamReader("Customer.txt",true);
                string record;
                while ((record = fileVariable.ReadLine()) != null)
                {
                    string[] splittedRecord = record.Split(',');
                    string Name = splittedRecord[0];
                    string pass = splittedRecord[1];
                    string role = splittedRecord[2];
                    string mail = splittedRecord[3];
                    string ID = splittedRecord[4];
                    string ContactNumber = splittedRecord[5];
                    string Address = splittedRecord[6];
                    string City = splittedRecord[7];
                    Customer cus = new Customer(Name, pass, mail, ID, Address, ContactNumber, City);
                    addCustomerInList(cus);
                }
                fileVariable.Close();
                return true;
            }
            return false;
        }
        public static void store_Data_In_File_Customer(Customer pro)//Funtion to Store product's Data in the File
        {
            StreamWriter myfile = new StreamWriter("Customers.txt",true);
            myfile.WriteLine(pro.getName() + "," + pro.getPassword() + "," + pro.getMail() + "," + pro.getID() + "," + pro.getAddress() + "," + pro.getContactNumber() + "," + pro.getCity());
            myfile.Flush();
            myfile.Close();

        }
    }
}
