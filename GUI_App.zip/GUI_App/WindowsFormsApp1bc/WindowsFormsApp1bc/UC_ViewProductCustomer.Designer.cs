﻿
namespace WindowsFormsApp1bc
{
    partial class UC_ViewProductCustomer
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tblCustomerViewProductPannel = new System.Windows.Forms.TableLayoutPanel();
            this.lblViewCustomerProduct = new System.Windows.Forms.Label();
            this.dtaGrdViewProductToCustomer = new System.Windows.Forms.DataGridView();
            this.tblCustomerViewProductPannel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtaGrdViewProductToCustomer)).BeginInit();
            this.SuspendLayout();
            // 
            // tblCustomerViewProductPannel
            // 
            this.tblCustomerViewProductPannel.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.tblCustomerViewProductPannel.ColumnCount = 1;
            this.tblCustomerViewProductPannel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblCustomerViewProductPannel.Controls.Add(this.lblViewCustomerProduct, 0, 0);
            this.tblCustomerViewProductPannel.Controls.Add(this.dtaGrdViewProductToCustomer, 0, 1);
            this.tblCustomerViewProductPannel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblCustomerViewProductPannel.Location = new System.Drawing.Point(0, 0);
            this.tblCustomerViewProductPannel.Name = "tblCustomerViewProductPannel";
            this.tblCustomerViewProductPannel.RowCount = 2;
            this.tblCustomerViewProductPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.15306F));
            this.tblCustomerViewProductPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 79.84694F));
            this.tblCustomerViewProductPannel.Size = new System.Drawing.Size(1206, 784);
            this.tblCustomerViewProductPannel.TabIndex = 0;
            // 
            // lblViewCustomerProduct
            // 
            this.lblViewCustomerProduct.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblViewCustomerProduct.AutoSize = true;
            this.lblViewCustomerProduct.Font = new System.Drawing.Font("Algerian", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblViewCustomerProduct.Location = new System.Drawing.Point(440, 54);
            this.lblViewCustomerProduct.Name = "lblViewCustomerProduct";
            this.lblViewCustomerProduct.Size = new System.Drawing.Size(325, 48);
            this.lblViewCustomerProduct.TabIndex = 0;
            this.lblViewCustomerProduct.Text = "View Product";
            // 
            // dtaGrdViewProductToCustomer
            // 
            this.dtaGrdViewProductToCustomer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtaGrdViewProductToCustomer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dtaGrdViewProductToCustomer.Location = new System.Drawing.Point(3, 160);
            this.dtaGrdViewProductToCustomer.Name = "dtaGrdViewProductToCustomer";
            this.dtaGrdViewProductToCustomer.RowHeadersWidth = 51;
            this.dtaGrdViewProductToCustomer.RowTemplate.Height = 24;
            this.dtaGrdViewProductToCustomer.Size = new System.Drawing.Size(1200, 621);
            this.dtaGrdViewProductToCustomer.TabIndex = 1;
            // 
            // UC_ViewProductCustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tblCustomerViewProductPannel);
            this.Name = "UC_ViewProductCustomer";
            this.Size = new System.Drawing.Size(1206, 784);
            this.Load += new System.EventHandler(this.UC_ViewProductCustomer_Load);
            this.tblCustomerViewProductPannel.ResumeLayout(false);
            this.tblCustomerViewProductPannel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtaGrdViewProductToCustomer)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tblCustomerViewProductPannel;
        private System.Windows.Forms.Label lblViewCustomerProduct;
        private System.Windows.Forms.DataGridView dtaGrdViewProductToCustomer;
    }
}
