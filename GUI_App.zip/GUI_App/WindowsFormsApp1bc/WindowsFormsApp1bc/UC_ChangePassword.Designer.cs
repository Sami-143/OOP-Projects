﻿
namespace WindowsFormsApp1bc
{
    partial class UC_ChangePassword
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblChangePassword = new System.Windows.Forms.Label();
            this.tblChangePassword = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.lblConfirmPassword = new System.Windows.Forms.Label();
            this.lblOldPassword = new System.Windows.Forms.Label();
            this.lblNewPAssword = new System.Windows.Forms.Label();
            this.txtNewPassword = new System.Windows.Forms.TextBox();
            this.txtOldPassword = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtConfirmPassword = new System.Windows.Forms.TextBox();
            this.btnChangePassword = new System.Windows.Forms.Button();
            this.lblValidationOldPass = new System.Windows.Forms.Label();
            this.lblValidationNewPass = new System.Windows.Forms.Label();
            this.lblValidationConfirmPass = new System.Windows.Forms.Label();
            this.tblChangePassword.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblChangePassword
            // 
            this.lblChangePassword.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblChangePassword.AutoSize = true;
            this.lblChangePassword.BackColor = System.Drawing.Color.Transparent;
            this.lblChangePassword.Font = new System.Drawing.Font("Algerian", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChangePassword.Location = new System.Drawing.Point(387, 50);
            this.lblChangePassword.Name = "lblChangePassword";
            this.lblChangePassword.Size = new System.Drawing.Size(433, 48);
            this.lblChangePassword.TabIndex = 0;
            this.lblChangePassword.Text = "Change Password";
            // 
            // tblChangePassword
            // 
            this.tblChangePassword.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.tblChangePassword.ColumnCount = 1;
            this.tblChangePassword.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblChangePassword.Controls.Add(this.lblChangePassword, 0, 0);
            this.tblChangePassword.Controls.Add(this.tableLayoutPanel1, 0, 1);
            this.tblChangePassword.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblChangePassword.Location = new System.Drawing.Point(0, 0);
            this.tblChangePassword.Name = "tblChangePassword";
            this.tblChangePassword.RowCount = 2;
            this.tblChangePassword.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19.29596F));
            this.tblChangePassword.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80.70404F));
            this.tblChangePassword.Size = new System.Drawing.Size(1208, 767);
            this.tblChangePassword.TabIndex = 0;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 464F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 298F));
            this.tableLayoutPanel1.Controls.Add(this.lblConfirmPassword, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.lblOldPassword, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.lblNewPAssword, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.txtNewPassword, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.txtOldPassword, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.txtConfirmPassword, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.btnChangePassword, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.lblValidationOldPass, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.lblValidationNewPass, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblValidationConfirmPass, 2, 2);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 151);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 47.14286F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 52.85714F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 103F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 243F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1202, 613);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // lblConfirmPassword
            // 
            this.lblConfirmPassword.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblConfirmPassword.AutoSize = true;
            this.lblConfirmPassword.Font = new System.Drawing.Font("Algerian", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConfirmPassword.Location = new System.Drawing.Point(87, 201);
            this.lblConfirmPassword.Name = "lblConfirmPassword";
            this.lblConfirmPassword.Size = new System.Drawing.Size(266, 30);
            this.lblConfirmPassword.TabIndex = 0;
            this.lblConfirmPassword.Text = "Confirm Password";
            // 
            // lblOldPassword
            // 
            this.lblOldPassword.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblOldPassword.AutoSize = true;
            this.lblOldPassword.Font = new System.Drawing.Font("Algerian", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOldPassword.Location = new System.Drawing.Point(117, 24);
            this.lblOldPassword.Name = "lblOldPassword";
            this.lblOldPassword.Size = new System.Drawing.Size(205, 30);
            this.lblOldPassword.TabIndex = 0;
            this.lblOldPassword.Text = "Old Password";
            // 
            // lblNewPAssword
            // 
            this.lblNewPAssword.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblNewPAssword.AutoSize = true;
            this.lblNewPAssword.Font = new System.Drawing.Font("Algerian", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewPAssword.Location = new System.Drawing.Point(114, 107);
            this.lblNewPAssword.Name = "lblNewPAssword";
            this.lblNewPAssword.Size = new System.Drawing.Size(211, 30);
            this.lblNewPAssword.TabIndex = 2;
            this.lblNewPAssword.Text = "New Password";
            // 
            // txtNewPassword
            // 
            this.txtNewPassword.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtNewPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNewPassword.Location = new System.Drawing.Point(499, 103);
            this.txtNewPassword.Name = "txtNewPassword";
            this.txtNewPassword.Size = new System.Drawing.Size(346, 38);
            this.txtNewPassword.TabIndex = 3;
            this.txtNewPassword.TextChanged += new System.EventHandler(this.txtNewPassword_TextChanged);
            // 
            // txtOldPassword
            // 
            this.txtOldPassword.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtOldPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOldPassword.Location = new System.Drawing.Point(499, 20);
            this.txtOldPassword.Name = "txtOldPassword";
            this.txtOldPassword.Size = new System.Drawing.Size(346, 38);
            this.txtOldPassword.TabIndex = 3;
            this.txtOldPassword.TextChanged += new System.EventHandler(this.txtOldPassword_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 266);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 17);
            this.label2.TabIndex = 1;
            // 
            // txtConfirmPassword
            // 
            this.txtConfirmPassword.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtConfirmPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtConfirmPassword.Location = new System.Drawing.Point(499, 197);
            this.txtConfirmPassword.Name = "txtConfirmPassword";
            this.txtConfirmPassword.Size = new System.Drawing.Size(346, 38);
            this.txtConfirmPassword.TabIndex = 4;
            this.txtConfirmPassword.TextChanged += new System.EventHandler(this.txtConfirmPassword_TextChanged);
            // 
            // btnChangePassword
            // 
            this.btnChangePassword.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnChangePassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChangePassword.Location = new System.Drawing.Point(608, 288);
            this.btnChangePassword.Name = "btnChangePassword";
            this.btnChangePassword.Size = new System.Drawing.Size(128, 58);
            this.btnChangePassword.TabIndex = 5;
            this.btnChangePassword.Text = "Change";
            this.btnChangePassword.UseVisualStyleBackColor = true;
            this.btnChangePassword.Click += new System.EventHandler(this.btnChangePassword_Click);
            // 
            // lblValidationOldPass
            // 
            this.lblValidationOldPass.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblValidationOldPass.AutoSize = true;
            this.lblValidationOldPass.Font = new System.Drawing.Font("Algerian", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValidationOldPass.Location = new System.Drawing.Point(907, 28);
            this.lblValidationOldPass.Name = "lblValidationOldPass";
            this.lblValidationOldPass.Size = new System.Drawing.Size(0, 22);
            this.lblValidationOldPass.TabIndex = 6;
            // 
            // lblValidationNewPass
            // 
            this.lblValidationNewPass.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblValidationNewPass.AutoSize = true;
            this.lblValidationNewPass.Font = new System.Drawing.Font("Algerian", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValidationNewPass.Location = new System.Drawing.Point(907, 111);
            this.lblValidationNewPass.Name = "lblValidationNewPass";
            this.lblValidationNewPass.Size = new System.Drawing.Size(0, 22);
            this.lblValidationNewPass.TabIndex = 6;
            // 
            // lblValidationConfirmPass
            // 
            this.lblValidationConfirmPass.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblValidationConfirmPass.AutoSize = true;
            this.lblValidationConfirmPass.Font = new System.Drawing.Font("Algerian", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValidationConfirmPass.Location = new System.Drawing.Point(907, 205);
            this.lblValidationConfirmPass.Name = "lblValidationConfirmPass";
            this.lblValidationConfirmPass.Size = new System.Drawing.Size(0, 22);
            this.lblValidationConfirmPass.TabIndex = 6;
            // 
            // UC_ChangePassword
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tblChangePassword);
            this.Name = "UC_ChangePassword";
            this.Size = new System.Drawing.Size(1208, 767);
            this.tblChangePassword.ResumeLayout(false);
            this.tblChangePassword.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label lblChangePassword;
        private System.Windows.Forms.TableLayoutPanel tblChangePassword;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblOldPassword;
        private System.Windows.Forms.Label lblConfirmPassword;
        private System.Windows.Forms.Label lblNewPAssword;
        private System.Windows.Forms.TextBox txtNewPassword;
        private System.Windows.Forms.TextBox txtOldPassword;
        private System.Windows.Forms.TextBox txtConfirmPassword;
        private System.Windows.Forms.Button btnChangePassword;
        private System.Windows.Forms.Label lblValidationOldPass;
        private System.Windows.Forms.Label lblValidationNewPass;
        private System.Windows.Forms.Label lblValidationConfirmPass;
    }
}
