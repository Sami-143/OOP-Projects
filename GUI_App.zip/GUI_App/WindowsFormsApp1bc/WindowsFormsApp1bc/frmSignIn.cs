﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1bc.DL;
using WindowsFormsApp1bc.BL;

namespace WindowsFormsApp1bc
{
    public partial class frmSignIn : Form
    {
        bool check;
        public frmSignIn()
        {
            InitializeComponent();

        }

        private void LogInButton_Click(object sender, EventArgs e)
        {
            DataDL.SetSignInObject(takeInputWithRoleSignIn());
            if (DataDL.GetSignInObject() != null)
            {
                DataDL.SetSignInObject(MUserDL.signIn(DataDL.GetSignInObject()));
                MUser u = new MUser(txtNameSignIn.Text, txtPasswordSignIn.Text);
                MUser user = MUserDL.signIn(u);
                if (DataDL.GetSignInObject() == null)
                {
                    MessageBox.Show("InValid Command");
                }
                else if (DataDL.GetSignInObject().isAdmin())
                {
                    this.Hide();
                    Admin admin = (Admin)user;
                    frmAdminMainMenu SignInObject = new frmAdminMainMenu(admin);
                    SignInObject.ShowDialog();
                    this.Show();
                }
                else if (DataDL.GetSignInObject().isCustomer())
                {
                    this.Hide();
                    Customer customer = (Customer)user;
                    frmCustomerMainMenu SignInObject = new frmCustomerMainMenu(customer);
                    SignInObject.ShowDialog();
                    this.Show();
                }
            }
        }

        private MUser takeInputWithRoleSignIn()
        {
            string name = txtNameSignIn.Text;

            string password = txtPasswordSignIn.Text;

            if (name != null && password != null)
            {
                MUser user = new MUser(name, password);
                return user;
            }
            else if(txtPasswordSignIn.Text.Length < 8)
            {
                MessageBox.Show("Password must be Greater than 8 Character");
            }
            return null;
        }

        private void linklblSignUp_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            frmSignUp signUP = new frmSignUp();
            signUP.ShowDialog();
        }
        static bool IsPasswordValid(string password)
        {
            // Check if the password length is at least 8 characters
            if (password.Length < 8)
            {
                return false;
            }

            // Check if the password contains at least one special character and one number
            bool containsSpecialChar = false;
            bool containsNumber = false;

            foreach (char c in password)
            {
                if (char.IsDigit(c))
                {
                    containsNumber = true;
                }
                else if (char.IsSymbol(c) || char.IsPunctuation(c))
                {
                    containsSpecialChar = true;
                }

                // If both conditions are met, no need to check further
                if (containsNumber && containsSpecialChar)
                {
                    break;
                }
            }

            // Return true if both conditions are met (valid password), otherwise false
            return containsNumber && containsSpecialChar;
        }

        private void txtPasswordSignIn_TextChanged(object sender, EventArgs e)
        {
            check = IsPasswordValid(txtPasswordSignIn.Text);
            if (check == true)
            {
                lblValidationSignInPass.ForeColor = Color.Green;
                lblValidationSignInPass.Text = "Valid";
            }
            else
            {
                lblValidationSignInPass.ForeColor = Color.Red;
                lblValidationSignInPass.Text = "Password 8 Character & Digits & Special Charcter";
            }
                
        }

        private void txtNameSignIn_TextChanged(object sender, EventArgs e)
        {
            check = IsAlphabetic(txtNameSignIn.Text);
            if (check == true)
            {
                lblValidationSignInName.ForeColor = Color.Green;
                lblValidationSignInName.Text = "Valid";
            }
            else
            {
                lblValidationSignInName.ForeColor = Color.Red;
                lblValidationSignInName.Text = "InValid";
            }
        }

        static bool IsAlphabetic(string input)
        {
            // Loop through each character in the input string
            foreach (char c in input)
            {
                // Use Char.IsLetter() method to check if the character is an alphabet
                if (!Char.IsLetter(c))
                {
                    return false;
                }
            }
            return true;
        }

        private void lblBackSignIn_Click(object sender, EventArgs e)
        {
            Hide();
            frmLoginMainMenu obj = new frmLoginMainMenu();
            obj.ShowDialog();
        }
        //This function takes a string password as input and checks the following conditions:
        //The password length must be at least 8 characters.
        //The password must contain at least one special character(symbol or punctuation) and at least one number.
        //If the password meets both of these conditions, the function returns true, indicating that the password is valid.Otherwise, it returns false.






    }
}
