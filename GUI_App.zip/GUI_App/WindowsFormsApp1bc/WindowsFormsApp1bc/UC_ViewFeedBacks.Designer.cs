﻿
namespace WindowsFormsApp1bc
{
    partial class UC_ViewFeedBacks
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblViewFeedbacks = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.lblViewFeedBack = new System.Windows.Forms.Label();
            this.btnViewFeedBackBack = new System.Windows.Forms.Button();
            this.dataGridViewFeedBack = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFeedBack)).BeginInit();
            this.SuspendLayout();
            // 
            // lblViewFeedbacks
            // 
            this.lblViewFeedbacks.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblViewFeedbacks.AutoSize = true;
            this.lblViewFeedbacks.Font = new System.Drawing.Font("Algerian", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblViewFeedbacks.Location = new System.Drawing.Point(555, 65);
            this.lblViewFeedbacks.Name = "lblViewFeedbacks";
            this.lblViewFeedbacks.Size = new System.Drawing.Size(389, 48);
            this.lblViewFeedbacks.TabIndex = 0;
            this.lblViewFeedbacks.Text = "VIEW FEEDBACKS";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.lblViewFeedbacks, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 22.99742F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 77.00259F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1500, 774);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 21.0174F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 78.9826F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 322F));
            this.tableLayoutPanel2.Controls.Add(this.lblViewFeedBack, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.dataGridViewFeedBack, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.btnViewFeedBackBack, 2, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 181);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 485F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1494, 590);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // lblViewFeedBack
            // 
            this.lblViewFeedBack.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblViewFeedBack.AutoSize = true;
            this.lblViewFeedBack.BackColor = System.Drawing.SystemColors.ControlLight;
            this.lblViewFeedBack.Font = new System.Drawing.Font("Algerian", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblViewFeedBack.Location = new System.Drawing.Point(14, 38);
            this.lblViewFeedBack.Name = "lblViewFeedBack";
            this.lblViewFeedBack.Size = new System.Drawing.Size(218, 28);
            this.lblViewFeedBack.TabIndex = 0;
            this.lblViewFeedBack.Text = "View FeedBack";
            // 
            // btnViewFeedBackBack
            // 
            this.btnViewFeedBackBack.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnViewFeedBackBack.Font = new System.Drawing.Font("Algerian", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewFeedBackBack.Location = new System.Drawing.Point(1272, 34);
            this.btnViewFeedBackBack.Name = "btnViewFeedBackBack";
            this.btnViewFeedBackBack.Size = new System.Drawing.Size(121, 36);
            this.btnViewFeedBackBack.TabIndex = 2;
            this.btnViewFeedBackBack.Text = "Back";
            this.btnViewFeedBackBack.UseVisualStyleBackColor = true;
            this.btnViewFeedBackBack.Click += new System.EventHandler(this.btnViewFeedBackBack_Click);
            // 
            // dataGridViewFeedBack
            // 
            this.dataGridViewFeedBack.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dataGridViewFeedBack.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewFeedBack.Location = new System.Drawing.Point(403, 128);
            this.dataGridViewFeedBack.Name = "dataGridViewFeedBack";
            this.dataGridViewFeedBack.RowHeadersWidth = 51;
            this.dataGridViewFeedBack.RowTemplate.Height = 24;
            this.dataGridViewFeedBack.Size = new System.Drawing.Size(610, 439);
            this.dataGridViewFeedBack.TabIndex = 1;
            // 
            // UC_ViewFeedBacks
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "UC_ViewFeedBacks";
            this.Size = new System.Drawing.Size(1500, 774);
            this.Load += new System.EventHandler(this.UC_ViewFeedBacks_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFeedBack)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblViewFeedbacks;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label lblViewFeedBack;
        private System.Windows.Forms.Button btnViewFeedBackBack;
        private System.Windows.Forms.DataGridView dataGridViewFeedBack;
    }
}
