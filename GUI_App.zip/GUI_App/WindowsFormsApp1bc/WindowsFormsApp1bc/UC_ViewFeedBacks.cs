﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1bc.BL;
using WindowsFormsApp1bc.DL;

namespace WindowsFormsApp1bc
{
    public partial class UC_ViewFeedBacks : UserControl
    {
        Admin admin;
        public UC_ViewFeedBacks(Admin admin)
        {
            InitializeComponent();
            this.admin = admin;
        }

        private void btnViewFeedBackBack_Click(object sender, EventArgs e)
        {
            Hide();
            frmAdminMainMenu obj = new frmAdminMainMenu(admin);
            obj.ShowDialog();
        }

        private void DisplayFeedbackInDataGridView(List<string> feedbackList)
        {
            // Assuming you have a DataGridView named "dataGridViewFeedback" in the UserControl
            dataGridViewFeedBack.Rows.Clear();

            foreach (string feedback in feedbackList)
            {
                int rowIndex = dataGridViewFeedBack.Rows.Add();
                dataGridViewFeedBack.Rows[rowIndex].Cells[0].Value = feedback;
            }
        }

        private List<string> readFeedbackFromFile()
        {


            // Read the feedback from the "feedback.txt" file
            if (File.Exists("Feedback.txt"))
            {
                using (StreamReader sr = new StreamReader("feedback.txt"))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        AdminDL.Feedbacks.Add(line);
                    }
                }
            }

            return AdminDL.Feedbacks;
        }


        private void DisplayFeedbackInDataGridView()
        {
            // Clear the existing rows and columns in the DataGridView
            dataGridViewFeedBack.Rows.Clear();
            dataGridViewFeedBack.Columns.Clear();

            // Add a single column to display the feedback
            DataGridViewTextBoxColumn feedbackColumn = new DataGridViewTextBoxColumn
            {
                Name = "colFeedback",
                HeaderText = "Feedback",
                AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill
            };
            dataGridViewFeedBack.Columns.Add(feedbackColumn);

            // Add the feedback data to the DataGridView
            foreach (string feedback in AdminDL.Feedbacks)
            {
                int rowIndex = dataGridViewFeedBack.Rows.Add(feedback);
            }
        }

        private void UC_ViewFeedBacks_Load(object sender, EventArgs e)
        {
            AdminDL.Feedbacks = readFeedbackFromFile();
            DisplayFeedbackInDataGridView();
        }
    }
}
