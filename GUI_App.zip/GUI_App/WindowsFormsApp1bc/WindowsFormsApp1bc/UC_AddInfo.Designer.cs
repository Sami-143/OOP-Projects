﻿
namespace WindowsFormsApp1bc
{
    partial class UC_AddInfo
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tblCustomerInfoPannel = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.CustomerInfoMiniPannel = new System.Windows.Forms.TableLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.lblCity = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtMail = new System.Windows.Forms.TextBox();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.txtContanct = new System.Windows.Forms.TextBox();
            this.txtID = new System.Windows.Forms.TextBox();
            this.btnAddToCart = new System.Windows.Forms.Button();
            this.lblInfoValidationAddress = new System.Windows.Forms.Label();
            this.lblInfoValidationCity = new System.Windows.Forms.Label();
            this.lblInfoValidationContactNo = new System.Windows.Forms.Label();
            this.lblInfoValidationID = new System.Windows.Forms.Label();
            this.btnAddInfoBack = new System.Windows.Forms.Label();
            this.tblCustomerInfoPannel.SuspendLayout();
            this.CustomerInfoMiniPannel.SuspendLayout();
            this.SuspendLayout();
            // 
            // tblCustomerInfoPannel
            // 
            this.tblCustomerInfoPannel.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.tblCustomerInfoPannel.ColumnCount = 1;
            this.tblCustomerInfoPannel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblCustomerInfoPannel.Controls.Add(this.label1, 0, 0);
            this.tblCustomerInfoPannel.Controls.Add(this.CustomerInfoMiniPannel, 0, 1);
            this.tblCustomerInfoPannel.Location = new System.Drawing.Point(0, 3);
            this.tblCustomerInfoPannel.Name = "tblCustomerInfoPannel";
            this.tblCustomerInfoPannel.RowCount = 2;
            this.tblCustomerInfoPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 17.65448F));
            this.tblCustomerInfoPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 82.34552F));
            this.tblCustomerInfoPannel.Size = new System.Drawing.Size(1194, 793);
            this.tblCustomerInfoPannel.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Algerian", 26F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(488, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(218, 49);
            this.label1.TabIndex = 0;
            this.label1.Text = "Add Info";
            // 
            // CustomerInfoMiniPannel
            // 
            this.CustomerInfoMiniPannel.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.CustomerInfoMiniPannel.ColumnCount = 3;
            this.CustomerInfoMiniPannel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 38.9485F));
            this.CustomerInfoMiniPannel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 61.0515F));
            this.CustomerInfoMiniPannel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 259F));
            this.CustomerInfoMiniPannel.Controls.Add(this.label2, 0, 0);
            this.CustomerInfoMiniPannel.Controls.Add(this.lblCity, 0, 1);
            this.CustomerInfoMiniPannel.Controls.Add(this.label4, 0, 2);
            this.CustomerInfoMiniPannel.Controls.Add(this.label5, 0, 3);
            this.CustomerInfoMiniPannel.Controls.Add(this.txtMail, 1, 0);
            this.CustomerInfoMiniPannel.Controls.Add(this.txtCity, 1, 1);
            this.CustomerInfoMiniPannel.Controls.Add(this.txtContanct, 1, 2);
            this.CustomerInfoMiniPannel.Controls.Add(this.txtID, 1, 3);
            this.CustomerInfoMiniPannel.Controls.Add(this.btnAddToCart, 1, 4);
            this.CustomerInfoMiniPannel.Controls.Add(this.lblInfoValidationAddress, 2, 0);
            this.CustomerInfoMiniPannel.Controls.Add(this.lblInfoValidationCity, 2, 1);
            this.CustomerInfoMiniPannel.Controls.Add(this.lblInfoValidationContactNo, 2, 2);
            this.CustomerInfoMiniPannel.Controls.Add(this.lblInfoValidationID, 2, 3);
            this.CustomerInfoMiniPannel.Controls.Add(this.btnAddInfoBack, 2, 5);
            this.CustomerInfoMiniPannel.Location = new System.Drawing.Point(3, 143);
            this.CustomerInfoMiniPannel.Name = "CustomerInfoMiniPannel";
            this.CustomerInfoMiniPannel.RowCount = 6;
            this.CustomerInfoMiniPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 47.90698F));
            this.CustomerInfoMiniPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 52.09302F));
            this.CustomerInfoMiniPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 93F));
            this.CustomerInfoMiniPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.CustomerInfoMiniPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 111F));
            this.CustomerInfoMiniPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 188F));
            this.CustomerInfoMiniPannel.Size = new System.Drawing.Size(1188, 647);
            this.CustomerInfoMiniPannel.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(45, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(270, 26);
            this.label2.TabIndex = 0;
            this.label2.Text = "Enter Email Address";
            // 
            // lblCity
            // 
            this.lblCity.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblCity.AutoSize = true;
            this.lblCity.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCity.Location = new System.Drawing.Point(74, 101);
            this.lblCity.Name = "lblCity";
            this.lblCity.Size = new System.Drawing.Size(212, 26);
            this.lblCity.TabIndex = 1;
            this.lblCity.Text = "Enter City Name";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(34, 187);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(293, 26);
            this.label4.TabIndex = 1;
            this.label4.Text = "Enter Contact Number";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(124, 284);
            this.label5.Name = "label5";
            this.label5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label5.Size = new System.Drawing.Size(112, 26);
            this.label5.TabIndex = 1;
            this.label5.Text = "Enter ID";
            // 
            // txtMail
            // 
            this.txtMail.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtMail.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMail.Location = new System.Drawing.Point(435, 20);
            this.txtMail.Name = "txtMail";
            this.txtMail.Size = new System.Drawing.Size(418, 34);
            this.txtMail.TabIndex = 2;
            this.txtMail.TextChanged += new System.EventHandler(this.txtMail_TextChanged);
            // 
            // txtCity
            // 
            this.txtCity.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtCity.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCity.Location = new System.Drawing.Point(435, 97);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(418, 34);
            this.txtCity.TabIndex = 2;
            this.txtCity.TextChanged += new System.EventHandler(this.txtCity_TextChanged);
            // 
            // txtContanct
            // 
            this.txtContanct.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtContanct.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContanct.Location = new System.Drawing.Point(435, 183);
            this.txtContanct.Name = "txtContanct";
            this.txtContanct.Size = new System.Drawing.Size(418, 34);
            this.txtContanct.TabIndex = 2;
            this.txtContanct.TextChanged += new System.EventHandler(this.txtContanct_TextChanged);
            // 
            // txtID
            // 
            this.txtID.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtID.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtID.Location = new System.Drawing.Point(435, 280);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(418, 34);
            this.txtID.TabIndex = 2;
            this.txtID.TextChanged += new System.EventHandler(this.txtID_TextChanged);
            // 
            // btnAddToCart
            // 
            this.btnAddToCart.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnAddToCart.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddToCart.Location = new System.Drawing.Point(554, 375);
            this.btnAddToCart.Name = "btnAddToCart";
            this.btnAddToCart.Size = new System.Drawing.Size(181, 54);
            this.btnAddToCart.TabIndex = 3;
            this.btnAddToCart.Text = "ADD ";
            this.btnAddToCart.UseVisualStyleBackColor = true;
            this.btnAddToCart.Click += new System.EventHandler(this.btnAddToCart_Click);
            // 
            // lblInfoValidationAddress
            // 
            this.lblInfoValidationAddress.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblInfoValidationAddress.AutoSize = true;
            this.lblInfoValidationAddress.Font = new System.Drawing.Font("Algerian", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInfoValidationAddress.Location = new System.Drawing.Point(931, 26);
            this.lblInfoValidationAddress.Name = "lblInfoValidationAddress";
            this.lblInfoValidationAddress.Size = new System.Drawing.Size(0, 22);
            this.lblInfoValidationAddress.TabIndex = 4;
            // 
            // lblInfoValidationCity
            // 
            this.lblInfoValidationCity.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblInfoValidationCity.AutoSize = true;
            this.lblInfoValidationCity.Font = new System.Drawing.Font("Algerian", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInfoValidationCity.Location = new System.Drawing.Point(931, 103);
            this.lblInfoValidationCity.Name = "lblInfoValidationCity";
            this.lblInfoValidationCity.Size = new System.Drawing.Size(0, 22);
            this.lblInfoValidationCity.TabIndex = 4;
            // 
            // lblInfoValidationContactNo
            // 
            this.lblInfoValidationContactNo.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblInfoValidationContactNo.AutoSize = true;
            this.lblInfoValidationContactNo.Font = new System.Drawing.Font("Algerian", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInfoValidationContactNo.Location = new System.Drawing.Point(931, 189);
            this.lblInfoValidationContactNo.Name = "lblInfoValidationContactNo";
            this.lblInfoValidationContactNo.Size = new System.Drawing.Size(0, 22);
            this.lblInfoValidationContactNo.TabIndex = 4;
            // 
            // lblInfoValidationID
            // 
            this.lblInfoValidationID.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblInfoValidationID.AutoSize = true;
            this.lblInfoValidationID.Font = new System.Drawing.Font("Algerian", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInfoValidationID.Location = new System.Drawing.Point(931, 286);
            this.lblInfoValidationID.Name = "lblInfoValidationID";
            this.lblInfoValidationID.Size = new System.Drawing.Size(0, 22);
            this.lblInfoValidationID.TabIndex = 4;
            // 
            // btnAddInfoBack
            // 
            this.btnAddInfoBack.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnAddInfoBack.AutoSize = true;
            this.btnAddInfoBack.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnAddInfoBack.Font = new System.Drawing.Font("Algerian", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddInfoBack.Location = new System.Drawing.Point(1014, 537);
            this.btnAddInfoBack.Name = "btnAddInfoBack";
            this.btnAddInfoBack.Size = new System.Drawing.Size(88, 31);
            this.btnAddInfoBack.TabIndex = 5;
            this.btnAddInfoBack.Text = "Back";
            this.btnAddInfoBack.Click += new System.EventHandler(this.btnAddInfoBack_Click);
            // 
            // UC_AddInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tblCustomerInfoPannel);
            this.Name = "UC_AddInfo";
            this.Size = new System.Drawing.Size(1197, 799);
            this.tblCustomerInfoPannel.ResumeLayout(false);
            this.tblCustomerInfoPannel.PerformLayout();
            this.CustomerInfoMiniPannel.ResumeLayout(false);
            this.CustomerInfoMiniPannel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tblCustomerInfoPannel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TableLayoutPanel CustomerInfoMiniPannel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblCity;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtMail;
        private System.Windows.Forms.TextBox txtCity;
        private System.Windows.Forms.TextBox txtContanct;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.Button btnAddToCart;
        private System.Windows.Forms.Label lblInfoValidationAddress;
        private System.Windows.Forms.Label lblInfoValidationCity;
        private System.Windows.Forms.Label lblInfoValidationContactNo;
        private System.Windows.Forms.Label lblInfoValidationID;
        private System.Windows.Forms.Label btnAddInfoBack;
    }
}
