﻿
namespace WindowsFormsApp1bc
{
    partial class UC_AddFeedBack
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tblCustomerFeedbackSecond = new System.Windows.Forms.TableLayoutPanel();
            this.cmdAdminAddNoodlesBack = new System.Windows.Forms.Button();
            this.lblAdminAddNoodlesName = new System.Windows.Forms.Label();
            this.txtCustomerAddFeedback = new System.Windows.Forms.TextBox();
            this.btn_AddFeedback = new System.Windows.Forms.Button();
            this.tblCustomerFeedbackFirst = new System.Windows.Forms.TableLayoutPanel();
            this.lblHeader = new System.Windows.Forms.Label();
            this.tblCustomerFeedbackSecond.SuspendLayout();
            this.tblCustomerFeedbackFirst.SuspendLayout();
            this.SuspendLayout();
            // 
            // tblCustomerFeedbackSecond
            // 
            this.tblCustomerFeedbackSecond.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.tblCustomerFeedbackSecond.ColumnCount = 2;
            this.tblCustomerFeedbackSecond.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblCustomerFeedbackSecond.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblCustomerFeedbackSecond.Controls.Add(this.cmdAdminAddNoodlesBack, 0, 1);
            this.tblCustomerFeedbackSecond.Controls.Add(this.lblAdminAddNoodlesName, 0, 0);
            this.tblCustomerFeedbackSecond.Controls.Add(this.txtCustomerAddFeedback, 1, 0);
            this.tblCustomerFeedbackSecond.Controls.Add(this.btn_AddFeedback, 1, 1);
            this.tblCustomerFeedbackSecond.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblCustomerFeedbackSecond.Location = new System.Drawing.Point(4, 168);
            this.tblCustomerFeedbackSecond.Margin = new System.Windows.Forms.Padding(4);
            this.tblCustomerFeedbackSecond.Name = "tblCustomerFeedbackSecond";
            this.tblCustomerFeedbackSecond.RowCount = 2;
            this.tblCustomerFeedbackSecond.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 46.51163F));
            this.tblCustomerFeedbackSecond.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 53.48837F));
            this.tblCustomerFeedbackSecond.Size = new System.Drawing.Size(1219, 628);
            this.tblCustomerFeedbackSecond.TabIndex = 3;
            // 
            // cmdAdminAddNoodlesBack
            // 
            this.cmdAdminAddNoodlesBack.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cmdAdminAddNoodlesBack.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.cmdAdminAddNoodlesBack.Font = new System.Drawing.Font("Algerian", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdAdminAddNoodlesBack.Location = new System.Drawing.Point(224, 431);
            this.cmdAdminAddNoodlesBack.Margin = new System.Windows.Forms.Padding(4);
            this.cmdAdminAddNoodlesBack.Name = "cmdAdminAddNoodlesBack";
            this.cmdAdminAddNoodlesBack.Size = new System.Drawing.Size(161, 58);
            this.cmdAdminAddNoodlesBack.TabIndex = 13;
            this.cmdAdminAddNoodlesBack.Text = "BACK";
            this.cmdAdminAddNoodlesBack.UseVisualStyleBackColor = false;
            this.cmdAdminAddNoodlesBack.Click += new System.EventHandler(this.cmdAdminAddNoodlesBack_Click);
            // 
            // lblAdminAddNoodlesName
            // 
            this.lblAdminAddNoodlesName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblAdminAddNoodlesName.AutoSize = true;
            this.lblAdminAddNoodlesName.Font = new System.Drawing.Font("Monotype Corsiva", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdminAddNoodlesName.Location = new System.Drawing.Point(127, 121);
            this.lblAdminAddNoodlesName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAdminAddNoodlesName.Name = "lblAdminAddNoodlesName";
            this.lblAdminAddNoodlesName.Size = new System.Drawing.Size(355, 49);
            this.lblAdminAddNoodlesName.TabIndex = 3;
            this.lblAdminAddNoodlesName.Text = "Enter Your Feedback:";
            // 
            // txtCustomerAddFeedback
            // 
            this.txtCustomerAddFeedback.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtCustomerAddFeedback.Font = new System.Drawing.Font("Algerian", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustomerAddFeedback.Location = new System.Drawing.Point(790, 131);
            this.txtCustomerAddFeedback.Margin = new System.Windows.Forms.Padding(4);
            this.txtCustomerAddFeedback.Name = "txtCustomerAddFeedback";
            this.txtCustomerAddFeedback.Size = new System.Drawing.Size(248, 29);
            this.txtCustomerAddFeedback.TabIndex = 8;
            // 
            // btn_AddFeedback
            // 
            this.btn_AddFeedback.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_AddFeedback.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btn_AddFeedback.Font = new System.Drawing.Font("Algerian", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_AddFeedback.Location = new System.Drawing.Point(833, 431);
            this.btn_AddFeedback.Margin = new System.Windows.Forms.Padding(4);
            this.btn_AddFeedback.Name = "btn_AddFeedback";
            this.btn_AddFeedback.Size = new System.Drawing.Size(161, 58);
            this.btn_AddFeedback.TabIndex = 12;
            this.btn_AddFeedback.Text = "ADD";
            this.btn_AddFeedback.UseVisualStyleBackColor = false;
            this.btn_AddFeedback.Click += new System.EventHandler(this.btn_AddFeedback_Click);
            // 
            // tblCustomerFeedbackFirst
            // 
            this.tblCustomerFeedbackFirst.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.tblCustomerFeedbackFirst.ColumnCount = 1;
            this.tblCustomerFeedbackFirst.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblCustomerFeedbackFirst.Controls.Add(this.tblCustomerFeedbackSecond, 0, 1);
            this.tblCustomerFeedbackFirst.Controls.Add(this.lblHeader, 0, 0);
            this.tblCustomerFeedbackFirst.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblCustomerFeedbackFirst.Location = new System.Drawing.Point(0, 0);
            this.tblCustomerFeedbackFirst.Margin = new System.Windows.Forms.Padding(4);
            this.tblCustomerFeedbackFirst.Name = "tblCustomerFeedbackFirst";
            this.tblCustomerFeedbackFirst.RowCount = 2;
            this.tblCustomerFeedbackFirst.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.58288F));
            this.tblCustomerFeedbackFirst.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 79.41712F));
            this.tblCustomerFeedbackFirst.Size = new System.Drawing.Size(1227, 800);
            this.tblCustomerFeedbackFirst.TabIndex = 1;
            // 
            // lblHeader
            // 
            this.lblHeader.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblHeader.AutoSize = true;
            this.lblHeader.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblHeader.Font = new System.Drawing.Font("Monotype Corsiva", 26.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeader.Location = new System.Drawing.Point(432, 55);
            this.lblHeader.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(362, 53);
            this.lblHeader.TabIndex = 2;
            this.lblHeader.Text = "Customer\'s Feedback";
            // 
            // UC_AddFeedBack
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tblCustomerFeedbackFirst);
            this.Name = "UC_AddFeedBack";
            this.Size = new System.Drawing.Size(1227, 800);
            this.tblCustomerFeedbackSecond.ResumeLayout(false);
            this.tblCustomerFeedbackSecond.PerformLayout();
            this.tblCustomerFeedbackFirst.ResumeLayout(false);
            this.tblCustomerFeedbackFirst.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tblCustomerFeedbackSecond;
        private System.Windows.Forms.Button cmdAdminAddNoodlesBack;
        private System.Windows.Forms.Label lblAdminAddNoodlesName;
        private System.Windows.Forms.TextBox txtCustomerAddFeedback;
        private System.Windows.Forms.Button btn_AddFeedback;
        private System.Windows.Forms.TableLayoutPanel tblCustomerFeedbackFirst;
        private System.Windows.Forms.Label lblHeader;
    }
}
