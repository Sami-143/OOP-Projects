﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1bc.BL;

namespace WindowsFormsApp1bc
{
    public partial class UC_BillCalculate : UserControl
    {
        Customer customer;
        public UC_BillCalculate(Customer customer)
        {
            InitializeComponent();
            this.customer = customer;
            lblFinalBill.Text = customer.calculateBill().ToString();
        }


        private void dataBind()
        {
            dataGridBill.DataSource = null;
            dataGridBill.DataSource = customer.getBuyProducts();
            dataGridBill.Refresh();
        }

        private void UC_BillCalculate_Load(object sender, EventArgs e)
        {
            dataBind();
        }

    }
}
