﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1bc.BL
{
    class Validations
    {

        /*public static bool isAllAlphabets(string input)
        {
            foreach(char i in input)
            {
                if(i.)
            }
        }

        public static bool isAllNumbers(string input)
        {

        }*/
    }
}
