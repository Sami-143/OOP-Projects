﻿
namespace WindowsFormsApp1bc
{
    partial class UC_ViewMostSoldProductAdmin
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_MostSoldProductAdminBack = new System.Windows.Forms.Button();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.lblMostSold = new System.Windows.Forms.Label();
            this.lblMostSoldQuantity = new System.Windows.Forms.Label();
            this.lblSoldQuantity = new System.Windows.Forms.Label();
            this.lblSoldName = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 486F));
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.btn_MostSoldProductAdminBack, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19.21053F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80.78947F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1122, 760);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label1.Font = new System.Drawing.Font("Algerian", 26F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(89, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(457, 49);
            this.label1.TabIndex = 0;
            this.label1.Text = "Most Sold Product";
            // 
            // btn_MostSoldProductAdminBack
            // 
            this.btn_MostSoldProductAdminBack.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_MostSoldProductAdminBack.Font = new System.Drawing.Font("Algerian", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_MostSoldProductAdminBack.Location = new System.Drawing.Point(802, 429);
            this.btn_MostSoldProductAdminBack.Name = "btn_MostSoldProductAdminBack";
            this.btn_MostSoldProductAdminBack.Size = new System.Drawing.Size(154, 48);
            this.btn_MostSoldProductAdminBack.TabIndex = 3;
            this.btn_MostSoldProductAdminBack.Text = "Back";
            this.btn_MostSoldProductAdminBack.UseVisualStyleBackColor = true;
            this.btn_MostSoldProductAdminBack.Click += new System.EventHandler(this.btn_MostSoldProductAdminBack_Click);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 51F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49F));
            this.tableLayoutPanel2.Controls.Add(this.lblMostSold, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.lblMostSoldQuantity, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.lblSoldQuantity, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.lblSoldName, 1, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 149);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 3;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 153F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 289F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(630, 608);
            this.tableLayoutPanel2.TabIndex = 4;
            // 
            // lblMostSold
            // 
            this.lblMostSold.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblMostSold.AutoSize = true;
            this.lblMostSold.BackColor = System.Drawing.SystemColors.ControlLight;
            this.lblMostSold.Font = new System.Drawing.Font("Algerian", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMostSold.Location = new System.Drawing.Point(92, 64);
            this.lblMostSold.Name = "lblMostSold";
            this.lblMostSold.Size = new System.Drawing.Size(136, 38);
            this.lblMostSold.TabIndex = 0;
            this.lblMostSold.Text = "Name : ";
            // 
            // lblMostSoldQuantity
            // 
            this.lblMostSoldQuantity.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblMostSoldQuantity.AutoSize = true;
            this.lblMostSoldQuantity.BackColor = System.Drawing.SystemColors.ControlLight;
            this.lblMostSoldQuantity.Font = new System.Drawing.Font("Algerian", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMostSoldQuantity.Location = new System.Drawing.Point(58, 223);
            this.lblMostSoldQuantity.Name = "lblMostSoldQuantity";
            this.lblMostSoldQuantity.Size = new System.Drawing.Size(205, 38);
            this.lblMostSoldQuantity.TabIndex = 0;
            this.lblMostSoldQuantity.Text = "Quantity : ";
            // 
            // lblSoldQuantity
            // 
            this.lblSoldQuantity.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblSoldQuantity.AutoSize = true;
            this.lblSoldQuantity.BackColor = System.Drawing.SystemColors.ControlLight;
            this.lblSoldQuantity.Font = new System.Drawing.Font("Algerian", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSoldQuantity.ForeColor = System.Drawing.Color.Red;
            this.lblSoldQuantity.Location = new System.Drawing.Point(475, 223);
            this.lblSoldQuantity.Name = "lblSoldQuantity";
            this.lblSoldQuantity.Size = new System.Drawing.Size(0, 38);
            this.lblSoldQuantity.TabIndex = 0;
            // 
            // lblSoldName
            // 
            this.lblSoldName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblSoldName.AutoSize = true;
            this.lblSoldName.BackColor = System.Drawing.SystemColors.ControlLight;
            this.lblSoldName.Font = new System.Drawing.Font("Algerian", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSoldName.ForeColor = System.Drawing.Color.Red;
            this.lblSoldName.Location = new System.Drawing.Point(475, 64);
            this.lblSoldName.Name = "lblSoldName";
            this.lblSoldName.Size = new System.Drawing.Size(0, 38);
            this.lblSoldName.TabIndex = 0;
            // 
            // UC_ViewMostSoldProductAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "UC_ViewMostSoldProductAdmin";
            this.Size = new System.Drawing.Size(1125, 763);
            this.Load += new System.EventHandler(this.UC_ViewMostSoldProductAdmin_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button btn_MostSoldProductAdminBack;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label lblMostSold;
        private System.Windows.Forms.Label lblMostSoldQuantity;
        private System.Windows.Forms.Label lblSoldQuantity;
        private System.Windows.Forms.Label lblSoldName;
    }
}
