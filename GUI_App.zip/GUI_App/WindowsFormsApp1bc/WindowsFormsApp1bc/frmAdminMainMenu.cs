﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1bc.BL;

namespace WindowsFormsApp1bc
{
    public partial class frmAdminMainMenu : Form
    {
        Admin admin;
        public frmAdminMainMenu(Admin admin)
        {
            InitializeComponent();
            this.admin = admin;
        }
        private void loadforms(UC_AddProducts frm)
        {
            try
            {
                this.screenpanel.Controls.Clear();
                UserControl f = frm as UserControl;

                f.Dock = DockStyle.Fill;
                this.screenpanel.Controls.Add(f);
                this.screenpanel.Tag = f;
                f.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void loadforms(UC_ViewProduct frm)
        {
            try
            {
                this.screenpanel.Controls.Clear();
                UserControl f = frm as UserControl;

                f.Dock = DockStyle.Fill;
                this.screenpanel.Controls.Add(f);
                this.screenpanel.Tag = f;
                f.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void loadforms(UC_SortingProduct frm)
        {
            try
            {
                this.screenpanel.Controls.Clear();
                UserControl f = frm as UserControl;

                f.Dock = DockStyle.Fill;
                this.screenpanel.Controls.Add(f);
                this.screenpanel.Tag = f;
                f.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void loadforms(UC_ChangePassword frm)
        {
            try
            {
                this.screenpanel.Controls.Clear();
                UserControl f = frm as UserControl;

                f.Dock = DockStyle.Fill;
                this.screenpanel.Controls.Add(f);
                this.screenpanel.Tag = f;
                f.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void loadforms(UC_ViewFeedBacks frm)
        {
            try
            {
                this.screenpanel.Controls.Clear();
                UserControl f = frm as UserControl;

                f.Dock = DockStyle.Fill;
                this.screenpanel.Controls.Add(f);
                this.screenpanel.Tag = f;
                f.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void loadforms(UC_ViewMostSoldProductAdmin frm)
        {
            try
            {
                this.screenpanel.Controls.Clear();
                UserControl f = frm as UserControl;

                f.Dock = DockStyle.Fill;
                this.screenpanel.Controls.Add(f);
                this.screenpanel.Tag = f;
                f.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
       

        private void lblAddProduct_Click(object sender, EventArgs e)
        {
            loadforms(new UC_AddProducts());
        }

        private void lblViewProduct_Click(object sender, EventArgs e)
        {
            loadforms(new UC_ViewProduct());
        }

        private void lblSorting_Click(object sender, EventArgs e)
        {
            loadforms(new UC_SortingProduct());
        }


        private void lblChangePassword_Click(object sender, EventArgs e)
        {
            loadforms(new UC_ChangePassword(this.admin));
        }

        private void lblFeedbackView_Click(object sender, EventArgs e)
        {
            loadforms(new UC_ViewFeedBacks(admin));
        }

        private void lblMostSoldProduct_Click(object sender, EventArgs e)
        {
            loadforms(new UC_ViewMostSoldProductAdmin(admin));
        }

        private void lblExitAdmin_Click(object sender, EventArgs e)
        {
            Hide();
            frmSignIn obj = new frmSignIn();
            obj.ShowDialog();
        }
    }
}
