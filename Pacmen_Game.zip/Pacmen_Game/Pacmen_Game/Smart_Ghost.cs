﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pacmen_Game
{
    //class Smart_Ghost : Ghost
    //{
    //    //public override GameCell Move_Ghost()
    //    //{
    //    //}
    //}
}
